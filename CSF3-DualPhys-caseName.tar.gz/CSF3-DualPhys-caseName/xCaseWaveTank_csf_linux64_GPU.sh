#!/bin/bash --login
#$ -cwd
#$ -l nvidia_v100=1
#$ -pe smp.pe 8

# 9.2 version of CUDA
module load libs/cuda/9.2.148

echo "Job is using $NGPUS GPU(s) with ID(s) $CUDA_VISIBLE_DEVICES and $NSLOTS CPU core(s)"

export OMP_NUM_THREADS=$NSLOTS


# "name" and "dirout" are named according to the testcase

export name=CaseWaveTank
export dirinput=/scratch/USERNAME/DualSPHysics_v5.2_1303/CaseWaveTank/CaseWaveTank_mDBC_out #File path to respective output folder
export diroutput=${dirinput}

# "executables" are renamed and called from their directory
export dirbin=/mnt/iusers01/fse-ugpgt01/mace01/USERNAME/DualSPHysics_v5.2_1303/bin/linux/DSGcc7
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${dirbin}
export dualsphysicsgpu="${dirbin}/DualSPHysics5.2_linux64"


${dualsphysicsgpu} -gpu ${dirinput}/${name} ${diroutput} -dirdataout data -svres