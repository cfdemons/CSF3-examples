LES of Channel Flow at Re_tau = 395 using OpenFOAM v2312

Please follow the below steps to:

==================
Run the simulation
==================

1. Copy the whole folder 'CSF3-ChannelRetau395-OpenFOAM' to folder ./scratch in your own directory on CSF3
2. Login to CSF3
3. Run command: cd ./scratch/CSF3-ChannelRetau395-OpenFOAM
4. Run command: chmod -R u+rwx *
5. Run command: qsub runCase (to start the simulation and it will finish in around 10 minutes)
6. Run command: qstat (to check if the simulation is running)
7. Run command: tail log.pisoLES (to check what time it has reached, simulation stops at 'Time = 400')

======================
Postprocess the result
======================

1. Run command: source setPostEnv
2. Run command: viewSurfaceU
3. Run command: viewProbeHistory
4. Run command: viewMeanProfiles
5. There should be three image files generated in the case folder
6. Download the image files to your local computer and view the results