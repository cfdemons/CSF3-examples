import numpy as np
import pandas as pd
from functionsOther import *

def loadBenchmarkJuanDNS(fdir,Retau):
    df = pd.read_csv(fdir+'Retau'+str(Retau)+'_statistics', delim_whitespace=True, skiprows=[0, 1], comment='%')

    yplus = df.iloc[:, 1].values
    Uplus = df.iloc[:, 2].values
    uplus = df.iloc[:, 3].values
    vplus = df.iloc[:, 4].values
    wplus = df.iloc[:, 5].values
    uvplus = df.iloc[:, 10].values
    uwplus = df.iloc[:, 11].values
    vwplus = df.iloc[:, 12].values
        
    return yplus, Uplus, uplus, vplus, wplus, uvplus, uwplus, vwplus
    
    
def loadBenchmarkAbeDNS(fdir,Retau):
    
    fname = fdir + 'ch' + str(Retau) + 'dns.dat'
    
    with open(fname, 'r') as fid:
        for i in range(54):
            fid.readline()
        meshsize = fid.readline().split(' x ')        
        ny = int(int(meshsize[1])/2)

    yplus_ugrid = np.zeros(ny)
    Uplus       = np.zeros(ny)
    uplus       = np.zeros(ny)
    wplus       = np.zeros(ny)

    yplus_vgrid = np.zeros(ny)
    vplus       = np.zeros(ny)
    uvplus      = np.zeros(ny)

    headerlines = 80
    with open(fname, 'r') as fid:
        for i in range(headerlines):
            fid.readline()  

        for i in range(ny):     
            temp = fid.readline().split()
            temp = [float(x) for x in temp]

            yplus_ugrid[i] = temp[1]
            Uplus[i]       = temp[2]
            uplus[i]       = temp[3] ** 0.5
            wplus[i]       = temp[4] ** 0.5

        del temp

        fid.readline()
        fid.readline()

        for i in range(ny):
            temp = fid.readline().split()
            temp = [float(x) for x in temp]

            yplus_vgrid[i] = temp[1]
            vplus[i]       = temp[2] ** 0.5
            uvplus[i]      = temp[3]

    return yplus_ugrid, yplus_vgrid, Uplus, uplus, vplus, wplus, uvplus
    
