import numpy as np
from functionsOther import *

def loadTensor(fdir):
    # Load vector data
    with open(fdir, 'r') as fid:
        rawtext = fid.readlines()
    skiplines = findKeyLine(rawtext,'internalField')+1

    with open(fdir, 'r') as fid:
        for i in range(skiplines):
            fid.readline()
        nc = int(fid.readline().strip())
        fid.readline()  
        vector = np.zeros((nc, 6))
        for i in range(nc):
            line = fid.readline().strip('()\n')
            vector[i, :] = list(map(float, line.split()))

    print("   ")
    print("     - Finish loading vector field from "+fdir)  
        
    return vector

def loadVector(fdir):
    # Load vector data
    with open(fdir, 'r') as fid:
        rawtext = fid.readlines()
    skiplines = findKeyLine(rawtext,'internalField')+1
    
    with open(fdir, 'r') as fid:
        for i in range(skiplines):
            fid.readline()
        nc = int(fid.readline().strip())
        fid.readline()  
        vector = np.zeros((nc, 3))
        for i in range(nc):
            line = fid.readline().strip('()\n')
            vector[i, :] = list(map(float, line.split()))

    print("   ")
    print("     - Finish loading vector field from "+fdir)  
        
    return vector

def loadScalar(fdir):
    # Load scalar data
    with open(fdir, 'r') as fid:
        rawtext = fid.readlines()
    skiplines = findKeyLine(rawtext,'internalField')+1
    
    with open(fdir, 'r') as fid:
        for i in range(skiplines):
            fid.readline()
        nc = int(fid.readline().strip())
        fid.readline()  
        scalar = np.zeros((nc))
        for i in range(nc):
            line = fid.readline().strip('\n')
            scalar[i] = line

    print("   ")
    print("     - Finish loading scalar field from "+fdir)            
    
    return scalar

def sortMesh(xyz, err):
    # Define the tolerance for sorting
    nc = xyz.shape[0]
    
    # Initialize variables
    nn = np.zeros(3, dtype=int)
    nn[:]=-1

    xline = []

    # Sort mesh grid
    for i in range(nc):
        if i == 0:
            nn += 1
            xline.append(xyz[0, :])
        else:
            for j in range(3):
                iflag = True
                for n in range(nn[j]+1):
                    if abs(xline[n][j] - xyz[i,j]) < err:
                        iflag = False
                        break
                if iflag:
                    nn[j] += 1
                    xline.append(np.zeros(3))
                    xline[nn[j]][j]=xyz[i,j]

    xline = np.array(xline)
    nn=nn+1

    # Extract x, y and z mesh grids
    xg = xline[:nn[0], 0]
    yg = xline[:nn[1], 1]
    zg = xline[:nn[2], 2]
    
    xg = np.sort(xg)
    yg = np.sort(yg)
    zg = np.sort(zg)

    nx = len(xg)
    ny = len(yg)
    nz = len(zg)

    # Output mesh information
    print("   ")
    print("     Converting disorganised to organised mesh...")
    print("   ")
    print("     - Finish sorting cell-centre mesh:")
    print("     - Total number of cells: ",str(nc))
    print("     - Number of cells in x direction: ",str(nx))
    print("     - Number of cells in y direction: ",str(ny))
    print("     - Number of cells in z direction: ",str(nz))
    print("   ")

    # Corresponding mesh IDs for all cells
    gi = np.zeros((nc, 3), dtype=int)

    for i in range(nc):
        gi[i, 0] = np.argmin(np.abs(xyz[i, 0] - xg))
        gi[i, 1] = np.argmin(np.abs(xyz[i, 1] - yg))
        gi[i, 2] = np.argmin(np.abs(xyz[i, 2] - zg))

    return xg, yg, zg, gi, nx, ny, nz, nc
    
    
def avgSymm(U):
    ny = U.shape[0]
    
    Usym = U

    for i in range(ny):
        Usym[i] = ( U[i] + U[ny-1-i] )/2.
    
    return Usym
    
def getTol(xyz,idir):
    zeroNum = 1.e-12

    g1d = abs(xyz[:,idir])
    ng = len(g1d) # Number of grids
    
    ymax = max(g1d)
    
    for i in range(ng):
        if g1d[i]<zeroNum:
          g1d[i] = ymax
    
    tol = min(g1d)*2
    
    return tol
    
    
    
    
    
