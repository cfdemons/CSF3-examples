#ifndef MPI
#define MPI
#endif
#ifndef UNDERSCORE
#define UNDERSCORE
#endif
#ifndef GLOBAL_LONG_LONG
#define GLOBAL_LONG_LONG
#endif
#ifndef PREFIX
#define PREFIX gslib_
#endif
#ifndef FPREFIX
#define FPREFIX fgslib_
#endif
