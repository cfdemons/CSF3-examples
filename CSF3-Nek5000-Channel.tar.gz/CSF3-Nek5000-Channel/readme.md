LES of Channel Flow at Re_tau = 395 using Nek5000 v19.0

Please follow the below steps to:

==================
Run the simulation
==================

1. Copy the whole folder 'CSF3-ChannelRetau395-Nek5000' to folder ./scratch in your own directory on CSF3
2. Login to CSF3
3. Run command: cd ./scratch/CSF3-ChannelRetau395-Nek5000
4. Run command: chmod -R u+rwx *
5. Run command: qsub compileCase (to compile the simulation)
6. Run command: qstat (to check if the compiling is finished)
6. Run command: qsub runCase (to run the simulation and it will finish within 10 minutes)
7. Run command: qstat (to check if the simulation is running)
8. Run command: tail ch.log.24 (to check what time it has reached, simulation stops at 'Time = 400')

======================
Postprocess the result
======================

1. Run command: source setPostEnv
2. Run command: viewProbeHistory
3. Run command: viewMeanProfiles
4. There should be two image files generated in the case folder
5. Download the image files to your local computer and view the results