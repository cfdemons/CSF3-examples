#!/bin/bash --login
#$ -cwd
#$ -l haswell          
#$ -l mem512

##### Load the module/software you need and its pre-requisits ##################

module load apps/binapps/paraview/5.10.1

##### Source the module ########################################################

pvpython test1.py 



