#!/bin/bash --login
#$ -pe amd.pe 10        # Where n is the number of cores: 2-168
#$ -cwd


##### Load the module/software you need and its pre-requisits ##################


module load apps/gcc/openfoam/v2106


##### Source the module ########################################################

source $foamDotFile


###### Run module commands #####################################################

decomposePar -force > deco.log

# Run OpenFOAM solver with error handling
if mpirun -n $NSLOTS pimpleFoam -parallel > log.log; then
    foamLog log.log
else
    echo "pimpleFoam failed" >&2
    exit 1
fi

# Generate plot using gnuplot
if ! gnuplot -e "set terminal jpeg size 1400,700; set output 'Residuals.jpeg'; set logscale y; \
    plot 'logs/Ux_0' u 1:2 w l title 'Ux', \
         'logs/Uy_0' u 1:2 w l title 'Uy', \
         'logs/Uz_0' u 1:2 w l title 'Uz', \
         'logs/pFinalRes_0' u 1:2 w l title 'p', \
         'logs/CourantMax_0' u 1:2 w l title 'Co', \
         'logs/k_0' u 1:2 w l title 'k', \
         'logs/nut_0' u 1:2 w l title 'nut'"; then
    echo "gnuplot failed" >&2
    exit 1
fi


reconstructPar -latestTime > rec.log

touch results.foam



