Laminar simulation of the flow in aorta using OpenFOAM 21.06

Please follow the below steps to:

================================================================================

1- Login to CSF3. In your local machine terminal, run the following:
	ssh -X "Your username"@csf3.itservices.manchester.ac.uk
	
2- Create a folder in CSF3:
	cd mnt/iusers01/mace01/"you username"/scratch/
	mkdir folder name

3- Copy the content of the following directory (folder) to CSF3. In your local machine terminal, run the following: 
	scp -r * mnt/iusers01/mace01/"you username"/scratch/"folder name"
	
4- In CSF3 submit the "run" file, i.e. bash script to run OpenFOAM:
	qsub run
	
================================================================================

Postprocessing the result:

5- Submit postProcessing.sh:
    qsub postProcessing.sh

6- Or run the postprocessing commands directly in CFS3 terminal as follows:
    module load apps/binapps/paraview/5.10.1
    pvpython test1.py 
    
7- Copy the results to your local machine. In your local machine terminal, run the following:
    scp -r mnt/iusers01/mace01/"you username"/scratch/"folder name"/*.jpeg .


