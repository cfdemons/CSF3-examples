# trace generated using paraview version 5.10.1
#import paraview
#paraview.compatibility.major = 5
#paraview.compatibility.minor = 10

#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# create a new 'OpenFOAMReader'
resultsfoam = OpenFOAMReader(registrationName='results.foam', FileName='/home/y95228da/Desktop/Masc-compute-cases/MC-trial1/results.foam')
resultsfoam.SkipZeroTime = 1
resultsfoam.CaseType = 'Reconstructed Case'
resultsfoam.LabelSize = '32-bit'
resultsfoam.ScalarSize = '64-bit (DP)'
resultsfoam.Createcelltopointfiltereddata = 1
resultsfoam.Adddimensionalunitstoarraynames = 0
resultsfoam.MeshRegions = ['internalMesh']
resultsfoam.CellArrays = ['U', 'nut', 'p']
resultsfoam.PointArrays = []
resultsfoam.LagrangianArrays = []
resultsfoam.Cachemesh = 1
resultsfoam.Decomposepolyhedra = 1
resultsfoam.ListtimestepsaccordingtocontrolDict = 0
resultsfoam.Lagrangianpositionswithoutextradata = 1
resultsfoam.Readzones = 0
resultsfoam.Copydatatocellzones = 0

# get animation scene
animationScene1 = GetAnimationScene()

# update animation scene based on data timesteps
animationScene1.UpdateAnimationUsingDataTimeSteps()

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')

# show data in view
resultsfoamDisplay = Show(resultsfoam, renderView1, 'UnstructuredGridRepresentation')

# get color transfer function/color map for 'p'
pLUT = GetColorTransferFunction('p')

# get opacity transfer function/opacity map for 'p'
pPWF = GetOpacityTransferFunction('p')

# trace defaults for the display properties.
resultsfoamDisplay.Selection = None
resultsfoamDisplay.Representation = 'Surface'
resultsfoamDisplay.ColorArrayName = ['POINTS', 'p']
resultsfoamDisplay.LookupTable = pLUT
resultsfoamDisplay.MapScalars = 1
resultsfoamDisplay.MultiComponentsMapping = 0
resultsfoamDisplay.InterpolateScalarsBeforeMapping = 1
resultsfoamDisplay.Opacity = 1.0
resultsfoamDisplay.PointSize = 2.0
resultsfoamDisplay.LineWidth = 1.0
resultsfoamDisplay.RenderLinesAsTubes = 0
resultsfoamDisplay.RenderPointsAsSpheres = 0
resultsfoamDisplay.Interpolation = 'Gouraud'
resultsfoamDisplay.Specular = 0.0
resultsfoamDisplay.SpecularColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.SpecularPower = 100.0
resultsfoamDisplay.Luminosity = 0.0
resultsfoamDisplay.Ambient = 0.0
resultsfoamDisplay.Diffuse = 1.0
resultsfoamDisplay.Roughness = 0.3
resultsfoamDisplay.Metallic = 0.0
resultsfoamDisplay.EdgeTint = [1.0, 1.0, 1.0]
resultsfoamDisplay.Anisotropy = 0.0
resultsfoamDisplay.AnisotropyRotation = 0.0
resultsfoamDisplay.BaseIOR = 1.5
resultsfoamDisplay.CoatStrength = 0.0
resultsfoamDisplay.CoatIOR = 2.0
resultsfoamDisplay.CoatRoughness = 0.0
resultsfoamDisplay.CoatColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.SelectTCoordArray = 'None'
resultsfoamDisplay.SelectNormalArray = 'None'
resultsfoamDisplay.SelectTangentArray = 'None'
resultsfoamDisplay.Texture = None
resultsfoamDisplay.RepeatTextures = 1
resultsfoamDisplay.InterpolateTextures = 0
resultsfoamDisplay.SeamlessU = 0
resultsfoamDisplay.SeamlessV = 0
resultsfoamDisplay.UseMipmapTextures = 0
resultsfoamDisplay.ShowTexturesOnBackface = 1
resultsfoamDisplay.BaseColorTexture = None
resultsfoamDisplay.NormalTexture = None
resultsfoamDisplay.NormalScale = 1.0
resultsfoamDisplay.CoatNormalTexture = None
resultsfoamDisplay.CoatNormalScale = 1.0
resultsfoamDisplay.MaterialTexture = None
resultsfoamDisplay.OcclusionStrength = 1.0
resultsfoamDisplay.AnisotropyTexture = None
resultsfoamDisplay.EmissiveTexture = None
resultsfoamDisplay.EmissiveFactor = [1.0, 1.0, 1.0]
resultsfoamDisplay.FlipTextures = 0
resultsfoamDisplay.BackfaceRepresentation = 'Follow Frontface'
resultsfoamDisplay.BackfaceAmbientColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.BackfaceOpacity = 1.0
resultsfoamDisplay.Position = [0.0, 0.0, 0.0]
resultsfoamDisplay.Scale = [1.0, 1.0, 1.0]
resultsfoamDisplay.Orientation = [0.0, 0.0, 0.0]
resultsfoamDisplay.Origin = [0.0, 0.0, 0.0]
resultsfoamDisplay.CoordinateShiftScaleMethod = 'Always Auto Shift Scale'
resultsfoamDisplay.Pickable = 1
resultsfoamDisplay.Triangulate = 0
resultsfoamDisplay.UseShaderReplacements = 0
resultsfoamDisplay.ShaderReplacements = ''
resultsfoamDisplay.NonlinearSubdivisionLevel = 1
resultsfoamDisplay.UseDataPartitions = 0
resultsfoamDisplay.OSPRayUseScaleArray = 'All Approximate'
resultsfoamDisplay.OSPRayScaleArray = 'p'
resultsfoamDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
resultsfoamDisplay.OSPRayMaterial = 'None'
resultsfoamDisplay.BlockSelectors = ['/']
resultsfoamDisplay.BlockColors = []
resultsfoamDisplay.BlockOpacities = []
resultsfoamDisplay.Orient = 0
resultsfoamDisplay.OrientationMode = 'Direction'
resultsfoamDisplay.SelectOrientationVectors = 'U'
resultsfoamDisplay.Scaling = 0
resultsfoamDisplay.ScaleMode = 'No Data Scaling Off'
resultsfoamDisplay.ScaleFactor = 0.005160355567932129
resultsfoamDisplay.SelectScaleArray = 'p'
resultsfoamDisplay.GlyphType = 'Arrow'
resultsfoamDisplay.UseGlyphTable = 0
resultsfoamDisplay.GlyphTableIndexArray = 'p'
resultsfoamDisplay.UseCompositeGlyphTable = 0
resultsfoamDisplay.UseGlyphCullingAndLOD = 0
resultsfoamDisplay.LODValues = []
resultsfoamDisplay.ColorByLODIndex = 0
resultsfoamDisplay.GaussianRadius = 0.00025801777839660643
resultsfoamDisplay.ShaderPreset = 'Sphere'
resultsfoamDisplay.CustomTriangleScale = 3
resultsfoamDisplay.CustomShader = """ // This custom shader code define a gaussian blur
 // Please take a look into vtkSMPointGaussianRepresentation.cxx
 // for other custom shader examples
 //VTK::Color::Impl
   float dist2 = dot(offsetVCVSOutput.xy,offsetVCVSOutput.xy);
   float gaussian = exp(-0.5*dist2);
   opacity = opacity*gaussian;
"""
resultsfoamDisplay.Emissive = 0
resultsfoamDisplay.ScaleByArray = 0
resultsfoamDisplay.SetScaleArray = ['POINTS', 'p']
resultsfoamDisplay.ScaleArrayComponent = ''
resultsfoamDisplay.UseScaleFunction = 1
resultsfoamDisplay.ScaleTransferFunction = 'PiecewiseFunction'
resultsfoamDisplay.OpacityByArray = 0
resultsfoamDisplay.OpacityArray = ['POINTS', 'p']
resultsfoamDisplay.OpacityArrayComponent = ''
resultsfoamDisplay.OpacityTransferFunction = 'PiecewiseFunction'
resultsfoamDisplay.DataAxesGrid = 'GridAxesRepresentation'
resultsfoamDisplay.SelectionCellLabelBold = 0
resultsfoamDisplay.SelectionCellLabelColor = [0.0, 1.0, 0.0]
resultsfoamDisplay.SelectionCellLabelFontFamily = 'Arial'
resultsfoamDisplay.SelectionCellLabelFontFile = ''
resultsfoamDisplay.SelectionCellLabelFontSize = 18
resultsfoamDisplay.SelectionCellLabelItalic = 0
resultsfoamDisplay.SelectionCellLabelJustification = 'Left'
resultsfoamDisplay.SelectionCellLabelOpacity = 1.0
resultsfoamDisplay.SelectionCellLabelShadow = 0
resultsfoamDisplay.SelectionPointLabelBold = 0
resultsfoamDisplay.SelectionPointLabelColor = [1.0, 1.0, 0.0]
resultsfoamDisplay.SelectionPointLabelFontFamily = 'Arial'
resultsfoamDisplay.SelectionPointLabelFontFile = ''
resultsfoamDisplay.SelectionPointLabelFontSize = 18
resultsfoamDisplay.SelectionPointLabelItalic = 0
resultsfoamDisplay.SelectionPointLabelJustification = 'Left'
resultsfoamDisplay.SelectionPointLabelOpacity = 1.0
resultsfoamDisplay.SelectionPointLabelShadow = 0
resultsfoamDisplay.PolarAxes = 'PolarAxesRepresentation'
resultsfoamDisplay.ScalarOpacityFunction = pPWF
resultsfoamDisplay.ScalarOpacityUnitDistance = 0.0008860789177993468
resultsfoamDisplay.UseSeparateOpacityArray = 0
resultsfoamDisplay.OpacityArrayName = ['POINTS', 'p']
resultsfoamDisplay.OpacityComponent = ''
resultsfoamDisplay.SelectMapper = 'Projected tetra'
resultsfoamDisplay.SamplingDimensions = [128, 128, 128]
resultsfoamDisplay.UseFloatingPointFrameBuffer = 1

# init the 'PiecewiseFunction' selected for 'OSPRayScaleFunction'
resultsfoamDisplay.OSPRayScaleFunction.Points = [0.0, 0.0, 0.5, 0.0, 1.0, 1.0, 0.5, 0.0]
resultsfoamDisplay.OSPRayScaleFunction.UseLogScale = 0

# init the 'Arrow' selected for 'GlyphType'
resultsfoamDisplay.GlyphType.TipResolution = 6
resultsfoamDisplay.GlyphType.TipRadius = 0.1
resultsfoamDisplay.GlyphType.TipLength = 0.35
resultsfoamDisplay.GlyphType.ShaftResolution = 6
resultsfoamDisplay.GlyphType.ShaftRadius = 0.03
resultsfoamDisplay.GlyphType.Invert = 0

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
resultsfoamDisplay.ScaleTransferFunction.Points = [-0.0022018137387931347, 0.0, 0.5, 0.0, 0.04348529875278473, 1.0, 0.5, 0.0]
resultsfoamDisplay.ScaleTransferFunction.UseLogScale = 0

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
resultsfoamDisplay.OpacityTransferFunction.Points = [-0.0022018137387931347, 0.0, 0.5, 0.0, 0.04348529875278473, 1.0, 0.5, 0.0]
resultsfoamDisplay.OpacityTransferFunction.UseLogScale = 0

# init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
resultsfoamDisplay.DataAxesGrid.XTitle = 'X Axis'
resultsfoamDisplay.DataAxesGrid.YTitle = 'Y Axis'
resultsfoamDisplay.DataAxesGrid.ZTitle = 'Z Axis'
resultsfoamDisplay.DataAxesGrid.XTitleFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.XTitleFontFile = ''
resultsfoamDisplay.DataAxesGrid.XTitleBold = 0
resultsfoamDisplay.DataAxesGrid.XTitleItalic = 0
resultsfoamDisplay.DataAxesGrid.XTitleFontSize = 12
resultsfoamDisplay.DataAxesGrid.XTitleShadow = 0
resultsfoamDisplay.DataAxesGrid.XTitleOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.YTitleFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.YTitleFontFile = ''
resultsfoamDisplay.DataAxesGrid.YTitleBold = 0
resultsfoamDisplay.DataAxesGrid.YTitleItalic = 0
resultsfoamDisplay.DataAxesGrid.YTitleFontSize = 12
resultsfoamDisplay.DataAxesGrid.YTitleShadow = 0
resultsfoamDisplay.DataAxesGrid.YTitleOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.ZTitleFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.ZTitleFontFile = ''
resultsfoamDisplay.DataAxesGrid.ZTitleBold = 0
resultsfoamDisplay.DataAxesGrid.ZTitleItalic = 0
resultsfoamDisplay.DataAxesGrid.ZTitleFontSize = 12
resultsfoamDisplay.DataAxesGrid.ZTitleShadow = 0
resultsfoamDisplay.DataAxesGrid.ZTitleOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.FacesToRender = 63
resultsfoamDisplay.DataAxesGrid.CullBackface = 0
resultsfoamDisplay.DataAxesGrid.CullFrontface = 1
resultsfoamDisplay.DataAxesGrid.ShowGrid = 0
resultsfoamDisplay.DataAxesGrid.ShowEdges = 1
resultsfoamDisplay.DataAxesGrid.ShowTicks = 1
resultsfoamDisplay.DataAxesGrid.LabelUniqueEdgesOnly = 1
resultsfoamDisplay.DataAxesGrid.AxesToLabel = 63
resultsfoamDisplay.DataAxesGrid.XLabelFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.XLabelFontFile = ''
resultsfoamDisplay.DataAxesGrid.XLabelBold = 0
resultsfoamDisplay.DataAxesGrid.XLabelItalic = 0
resultsfoamDisplay.DataAxesGrid.XLabelFontSize = 12
resultsfoamDisplay.DataAxesGrid.XLabelShadow = 0
resultsfoamDisplay.DataAxesGrid.XLabelOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.YLabelFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.YLabelFontFile = ''
resultsfoamDisplay.DataAxesGrid.YLabelBold = 0
resultsfoamDisplay.DataAxesGrid.YLabelItalic = 0
resultsfoamDisplay.DataAxesGrid.YLabelFontSize = 12
resultsfoamDisplay.DataAxesGrid.YLabelShadow = 0
resultsfoamDisplay.DataAxesGrid.YLabelOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.ZLabelFontFamily = 'Arial'
resultsfoamDisplay.DataAxesGrid.ZLabelFontFile = ''
resultsfoamDisplay.DataAxesGrid.ZLabelBold = 0
resultsfoamDisplay.DataAxesGrid.ZLabelItalic = 0
resultsfoamDisplay.DataAxesGrid.ZLabelFontSize = 12
resultsfoamDisplay.DataAxesGrid.ZLabelShadow = 0
resultsfoamDisplay.DataAxesGrid.ZLabelOpacity = 1.0
resultsfoamDisplay.DataAxesGrid.XAxisNotation = 'Mixed'
resultsfoamDisplay.DataAxesGrid.XAxisPrecision = 2
resultsfoamDisplay.DataAxesGrid.XAxisUseCustomLabels = 0
resultsfoamDisplay.DataAxesGrid.XAxisLabels = []
resultsfoamDisplay.DataAxesGrid.YAxisNotation = 'Mixed'
resultsfoamDisplay.DataAxesGrid.YAxisPrecision = 2
resultsfoamDisplay.DataAxesGrid.YAxisUseCustomLabels = 0
resultsfoamDisplay.DataAxesGrid.YAxisLabels = []
resultsfoamDisplay.DataAxesGrid.ZAxisNotation = 'Mixed'
resultsfoamDisplay.DataAxesGrid.ZAxisPrecision = 2
resultsfoamDisplay.DataAxesGrid.ZAxisUseCustomLabels = 0
resultsfoamDisplay.DataAxesGrid.ZAxisLabels = []
resultsfoamDisplay.DataAxesGrid.UseCustomBounds = 0
resultsfoamDisplay.DataAxesGrid.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]

# init the 'PolarAxesRepresentation' selected for 'PolarAxes'
resultsfoamDisplay.PolarAxes.Visibility = 0
resultsfoamDisplay.PolarAxes.Translation = [0.0, 0.0, 0.0]
resultsfoamDisplay.PolarAxes.Scale = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.Orientation = [0.0, 0.0, 0.0]
resultsfoamDisplay.PolarAxes.EnableCustomBounds = [0, 0, 0]
resultsfoamDisplay.PolarAxes.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
resultsfoamDisplay.PolarAxes.EnableCustomRange = 0
resultsfoamDisplay.PolarAxes.CustomRange = [0.0, 1.0]
resultsfoamDisplay.PolarAxes.PolarAxisVisibility = 1
resultsfoamDisplay.PolarAxes.RadialAxesVisibility = 1
resultsfoamDisplay.PolarAxes.DrawRadialGridlines = 1
resultsfoamDisplay.PolarAxes.PolarArcsVisibility = 1
resultsfoamDisplay.PolarAxes.DrawPolarArcsGridlines = 1
resultsfoamDisplay.PolarAxes.NumberOfRadialAxes = 0
resultsfoamDisplay.PolarAxes.AutoSubdividePolarAxis = 1
resultsfoamDisplay.PolarAxes.NumberOfPolarAxis = 0
resultsfoamDisplay.PolarAxes.MinimumRadius = 0.0
resultsfoamDisplay.PolarAxes.MinimumAngle = 0.0
resultsfoamDisplay.PolarAxes.MaximumAngle = 90.0
resultsfoamDisplay.PolarAxes.RadialAxesOriginToPolarAxis = 1
resultsfoamDisplay.PolarAxes.Ratio = 1.0
resultsfoamDisplay.PolarAxes.PolarAxisColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.PolarArcsColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.LastRadialAxisColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.SecondaryPolarArcsColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesColor = [1.0, 1.0, 1.0]
resultsfoamDisplay.PolarAxes.PolarAxisTitleVisibility = 1
resultsfoamDisplay.PolarAxes.PolarAxisTitle = 'Radial Distance'
resultsfoamDisplay.PolarAxes.PolarAxisTitleLocation = 'Bottom'
resultsfoamDisplay.PolarAxes.PolarLabelVisibility = 1
resultsfoamDisplay.PolarAxes.PolarLabelFormat = '%-#6.3g'
resultsfoamDisplay.PolarAxes.PolarLabelExponentLocation = 'Labels'
resultsfoamDisplay.PolarAxes.RadialLabelVisibility = 1
resultsfoamDisplay.PolarAxes.RadialLabelFormat = '%-#3.1f'
resultsfoamDisplay.PolarAxes.RadialLabelLocation = 'Bottom'
resultsfoamDisplay.PolarAxes.RadialUnitsVisibility = 1
resultsfoamDisplay.PolarAxes.ScreenSize = 10.0
resultsfoamDisplay.PolarAxes.PolarAxisTitleOpacity = 1.0
resultsfoamDisplay.PolarAxes.PolarAxisTitleFontFamily = 'Arial'
resultsfoamDisplay.PolarAxes.PolarAxisTitleFontFile = ''
resultsfoamDisplay.PolarAxes.PolarAxisTitleBold = 0
resultsfoamDisplay.PolarAxes.PolarAxisTitleItalic = 0
resultsfoamDisplay.PolarAxes.PolarAxisTitleShadow = 0
resultsfoamDisplay.PolarAxes.PolarAxisTitleFontSize = 12
resultsfoamDisplay.PolarAxes.PolarAxisLabelOpacity = 1.0
resultsfoamDisplay.PolarAxes.PolarAxisLabelFontFamily = 'Arial'
resultsfoamDisplay.PolarAxes.PolarAxisLabelFontFile = ''
resultsfoamDisplay.PolarAxes.PolarAxisLabelBold = 0
resultsfoamDisplay.PolarAxes.PolarAxisLabelItalic = 0
resultsfoamDisplay.PolarAxes.PolarAxisLabelShadow = 0
resultsfoamDisplay.PolarAxes.PolarAxisLabelFontSize = 12
resultsfoamDisplay.PolarAxes.LastRadialAxisTextOpacity = 1.0
resultsfoamDisplay.PolarAxes.LastRadialAxisTextFontFamily = 'Arial'
resultsfoamDisplay.PolarAxes.LastRadialAxisTextFontFile = ''
resultsfoamDisplay.PolarAxes.LastRadialAxisTextBold = 0
resultsfoamDisplay.PolarAxes.LastRadialAxisTextItalic = 0
resultsfoamDisplay.PolarAxes.LastRadialAxisTextShadow = 0
resultsfoamDisplay.PolarAxes.LastRadialAxisTextFontSize = 12
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextOpacity = 1.0
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextFontFamily = 'Arial'
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextFontFile = ''
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextBold = 0
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextItalic = 0
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextShadow = 0
resultsfoamDisplay.PolarAxes.SecondaryRadialAxesTextFontSize = 12
resultsfoamDisplay.PolarAxes.EnableDistanceLOD = 1
resultsfoamDisplay.PolarAxes.DistanceLODThreshold = 0.7
resultsfoamDisplay.PolarAxes.EnableViewAngleLOD = 1
resultsfoamDisplay.PolarAxes.ViewAngleLODThreshold = 0.7
resultsfoamDisplay.PolarAxes.SmallestVisiblePolarAngle = 0.5
resultsfoamDisplay.PolarAxes.PolarTicksVisibility = 1
resultsfoamDisplay.PolarAxes.ArcTicksOriginToPolarAxis = 1
resultsfoamDisplay.PolarAxes.TickLocation = 'Both'
resultsfoamDisplay.PolarAxes.AxisTickVisibility = 1
resultsfoamDisplay.PolarAxes.AxisMinorTickVisibility = 0
resultsfoamDisplay.PolarAxes.ArcTickVisibility = 1
resultsfoamDisplay.PolarAxes.ArcMinorTickVisibility = 0
resultsfoamDisplay.PolarAxes.DeltaAngleMajor = 10.0
resultsfoamDisplay.PolarAxes.DeltaAngleMinor = 5.0
resultsfoamDisplay.PolarAxes.PolarAxisMajorTickSize = 0.0
resultsfoamDisplay.PolarAxes.PolarAxisTickRatioSize = 0.3
resultsfoamDisplay.PolarAxes.PolarAxisMajorTickThickness = 1.0
resultsfoamDisplay.PolarAxes.PolarAxisTickRatioThickness = 0.5
resultsfoamDisplay.PolarAxes.LastRadialAxisMajorTickSize = 0.0
resultsfoamDisplay.PolarAxes.LastRadialAxisTickRatioSize = 0.3
resultsfoamDisplay.PolarAxes.LastRadialAxisMajorTickThickness = 1.0
resultsfoamDisplay.PolarAxes.LastRadialAxisTickRatioThickness = 0.5
resultsfoamDisplay.PolarAxes.ArcMajorTickSize = 0.0
resultsfoamDisplay.PolarAxes.ArcTickRatioSize = 0.3
resultsfoamDisplay.PolarAxes.ArcMajorTickThickness = 1.0
resultsfoamDisplay.PolarAxes.ArcTickRatioThickness = 0.5
resultsfoamDisplay.PolarAxes.Use2DMode = 0
resultsfoamDisplay.PolarAxes.UseLogAxis = 0

# reset view to fit data
renderView1.ResetCamera(False)

# show color bar/color legend
resultsfoamDisplay.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

animationScene1.GoToLast()

# create a new 'Slice'
slice1 = Slice(registrationName='Slice1', Input=resultsfoam)
slice1.SliceType = 'Plane'
slice1.HyperTreeGridSlicer = 'Plane'
slice1.UseDual = 0
slice1.Crinkleslice = 0
slice1.Triangulatetheslice = 1
slice1.Mergeduplicatedpointsintheslice = 1
slice1.SliceOffsetValues = [0.0]

# init the 'Plane' selected for 'SliceType'
slice1.SliceType.Origin = [-0.00026979646645486355, 0.003016475820913911, 0.007492445409297943]
slice1.SliceType.Normal = [1.0, 0.0, 0.0]
slice1.SliceType.Offset = 0.0

# init the 'Plane' selected for 'HyperTreeGridSlicer'
slice1.HyperTreeGridSlicer.Origin = [-0.00026979646645486355, 0.003016475820913911, 0.007492445409297943]
slice1.HyperTreeGridSlicer.Normal = [1.0, 0.0, 0.0]
slice1.HyperTreeGridSlicer.Offset = 0.0

# Properties modified on slice1.SliceType
slice1.SliceType.Origin = [0.0011872335821161094, -0.004876311427091391, -0.0069317731491810655]
slice1.SliceType.Normal = [0.9764730099474658, 0.21151611428375, -0.041968967612276135]

# show data in view
slice1Display = Show(slice1, renderView1, 'GeometryRepresentation')

# trace defaults for the display properties.
slice1Display.Selection = None
slice1Display.Representation = 'Surface'
slice1Display.ColorArrayName = ['POINTS', 'p']
slice1Display.LookupTable = pLUT
slice1Display.MapScalars = 1
slice1Display.MultiComponentsMapping = 0
slice1Display.InterpolateScalarsBeforeMapping = 1
slice1Display.Opacity = 1.0
slice1Display.PointSize = 2.0
slice1Display.LineWidth = 1.0
slice1Display.RenderLinesAsTubes = 0
slice1Display.RenderPointsAsSpheres = 0
slice1Display.Interpolation = 'Gouraud'
slice1Display.Specular = 0.0
slice1Display.SpecularColor = [1.0, 1.0, 1.0]
slice1Display.SpecularPower = 100.0
slice1Display.Luminosity = 0.0
slice1Display.Ambient = 0.0
slice1Display.Diffuse = 1.0
slice1Display.Roughness = 0.3
slice1Display.Metallic = 0.0
slice1Display.EdgeTint = [1.0, 1.0, 1.0]
slice1Display.Anisotropy = 0.0
slice1Display.AnisotropyRotation = 0.0
slice1Display.BaseIOR = 1.5
slice1Display.CoatStrength = 0.0
slice1Display.CoatIOR = 2.0
slice1Display.CoatRoughness = 0.0
slice1Display.CoatColor = [1.0, 1.0, 1.0]
slice1Display.SelectTCoordArray = 'None'
slice1Display.SelectNormalArray = 'None'
slice1Display.SelectTangentArray = 'None'
slice1Display.Texture = None
slice1Display.RepeatTextures = 1
slice1Display.InterpolateTextures = 0
slice1Display.SeamlessU = 0
slice1Display.SeamlessV = 0
slice1Display.UseMipmapTextures = 0
slice1Display.ShowTexturesOnBackface = 1
slice1Display.BaseColorTexture = None
slice1Display.NormalTexture = None
slice1Display.NormalScale = 1.0
slice1Display.CoatNormalTexture = None
slice1Display.CoatNormalScale = 1.0
slice1Display.MaterialTexture = None
slice1Display.OcclusionStrength = 1.0
slice1Display.AnisotropyTexture = None
slice1Display.EmissiveTexture = None
slice1Display.EmissiveFactor = [1.0, 1.0, 1.0]
slice1Display.FlipTextures = 0
slice1Display.BackfaceRepresentation = 'Follow Frontface'
slice1Display.BackfaceAmbientColor = [1.0, 1.0, 1.0]
slice1Display.BackfaceOpacity = 1.0
slice1Display.Position = [0.0, 0.0, 0.0]
slice1Display.Scale = [1.0, 1.0, 1.0]
slice1Display.Orientation = [0.0, 0.0, 0.0]
slice1Display.Origin = [0.0, 0.0, 0.0]
slice1Display.CoordinateShiftScaleMethod = 'Always Auto Shift Scale'
slice1Display.Pickable = 1
slice1Display.Triangulate = 0
slice1Display.UseShaderReplacements = 0
slice1Display.ShaderReplacements = ''
slice1Display.NonlinearSubdivisionLevel = 1
slice1Display.UseDataPartitions = 0
slice1Display.OSPRayUseScaleArray = 'All Approximate'
slice1Display.OSPRayScaleArray = 'p'
slice1Display.OSPRayScaleFunction = 'PiecewiseFunction'
slice1Display.OSPRayMaterial = 'None'
slice1Display.BlockSelectors = ['/']
slice1Display.BlockColors = []
slice1Display.BlockOpacities = []
slice1Display.Orient = 0
slice1Display.OrientationMode = 'Direction'
slice1Display.SelectOrientationVectors = 'U'
slice1Display.Scaling = 0
slice1Display.ScaleMode = 'No Data Scaling Off'
slice1Display.ScaleFactor = 0.0051532225683331495
slice1Display.SelectScaleArray = 'p'
slice1Display.GlyphType = 'Arrow'
slice1Display.UseGlyphTable = 0
slice1Display.GlyphTableIndexArray = 'p'
slice1Display.UseCompositeGlyphTable = 0
slice1Display.UseGlyphCullingAndLOD = 0
slice1Display.LODValues = []
slice1Display.ColorByLODIndex = 0
slice1Display.GaussianRadius = 0.0002576611284166575
slice1Display.ShaderPreset = 'Sphere'
slice1Display.CustomTriangleScale = 3
slice1Display.CustomShader = """ // This custom shader code define a gaussian blur
 // Please take a look into vtkSMPointGaussianRepresentation.cxx
 // for other custom shader examples
 //VTK::Color::Impl
   float dist2 = dot(offsetVCVSOutput.xy,offsetVCVSOutput.xy);
   float gaussian = exp(-0.5*dist2);
   opacity = opacity*gaussian;
"""
slice1Display.Emissive = 0
slice1Display.ScaleByArray = 0
slice1Display.SetScaleArray = ['POINTS', 'p']
slice1Display.ScaleArrayComponent = ''
slice1Display.UseScaleFunction = 1
slice1Display.ScaleTransferFunction = 'PiecewiseFunction'
slice1Display.OpacityByArray = 0
slice1Display.OpacityArray = ['POINTS', 'p']
slice1Display.OpacityArrayComponent = ''
slice1Display.OpacityTransferFunction = 'PiecewiseFunction'
slice1Display.DataAxesGrid = 'GridAxesRepresentation'
slice1Display.SelectionCellLabelBold = 0
slice1Display.SelectionCellLabelColor = [0.0, 1.0, 0.0]
slice1Display.SelectionCellLabelFontFamily = 'Arial'
slice1Display.SelectionCellLabelFontFile = ''
slice1Display.SelectionCellLabelFontSize = 18
slice1Display.SelectionCellLabelItalic = 0
slice1Display.SelectionCellLabelJustification = 'Left'
slice1Display.SelectionCellLabelOpacity = 1.0
slice1Display.SelectionCellLabelShadow = 0
slice1Display.SelectionPointLabelBold = 0
slice1Display.SelectionPointLabelColor = [1.0, 1.0, 0.0]
slice1Display.SelectionPointLabelFontFamily = 'Arial'
slice1Display.SelectionPointLabelFontFile = ''
slice1Display.SelectionPointLabelFontSize = 18
slice1Display.SelectionPointLabelItalic = 0
slice1Display.SelectionPointLabelJustification = 'Left'
slice1Display.SelectionPointLabelOpacity = 1.0
slice1Display.SelectionPointLabelShadow = 0
slice1Display.PolarAxes = 'PolarAxesRepresentation'

# init the 'PiecewiseFunction' selected for 'OSPRayScaleFunction'
slice1Display.OSPRayScaleFunction.Points = [0.0, 0.0, 0.5, 0.0, 1.0, 1.0, 0.5, 0.0]
slice1Display.OSPRayScaleFunction.UseLogScale = 0

# init the 'Arrow' selected for 'GlyphType'
slice1Display.GlyphType.TipResolution = 6
slice1Display.GlyphType.TipRadius = 0.1
slice1Display.GlyphType.TipLength = 0.35
slice1Display.GlyphType.ShaftResolution = 6
slice1Display.GlyphType.ShaftRadius = 0.03
slice1Display.GlyphType.Invert = 0

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
slice1Display.ScaleTransferFunction.Points = [-0.0007583058904856443, 0.0, 0.5, 0.0, 0.03757954761385918, 1.0, 0.5, 0.0]
slice1Display.ScaleTransferFunction.UseLogScale = 0

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
slice1Display.OpacityTransferFunction.Points = [-0.0007583058904856443, 0.0, 0.5, 0.0, 0.03757954761385918, 1.0, 0.5, 0.0]
slice1Display.OpacityTransferFunction.UseLogScale = 0

# init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
slice1Display.DataAxesGrid.XTitle = 'X Axis'
slice1Display.DataAxesGrid.YTitle = 'Y Axis'
slice1Display.DataAxesGrid.ZTitle = 'Z Axis'
slice1Display.DataAxesGrid.XTitleFontFamily = 'Arial'
slice1Display.DataAxesGrid.XTitleFontFile = ''
slice1Display.DataAxesGrid.XTitleBold = 0
slice1Display.DataAxesGrid.XTitleItalic = 0
slice1Display.DataAxesGrid.XTitleFontSize = 12
slice1Display.DataAxesGrid.XTitleShadow = 0
slice1Display.DataAxesGrid.XTitleOpacity = 1.0
slice1Display.DataAxesGrid.YTitleFontFamily = 'Arial'
slice1Display.DataAxesGrid.YTitleFontFile = ''
slice1Display.DataAxesGrid.YTitleBold = 0
slice1Display.DataAxesGrid.YTitleItalic = 0
slice1Display.DataAxesGrid.YTitleFontSize = 12
slice1Display.DataAxesGrid.YTitleShadow = 0
slice1Display.DataAxesGrid.YTitleOpacity = 1.0
slice1Display.DataAxesGrid.ZTitleFontFamily = 'Arial'
slice1Display.DataAxesGrid.ZTitleFontFile = ''
slice1Display.DataAxesGrid.ZTitleBold = 0
slice1Display.DataAxesGrid.ZTitleItalic = 0
slice1Display.DataAxesGrid.ZTitleFontSize = 12
slice1Display.DataAxesGrid.ZTitleShadow = 0
slice1Display.DataAxesGrid.ZTitleOpacity = 1.0
slice1Display.DataAxesGrid.FacesToRender = 63
slice1Display.DataAxesGrid.CullBackface = 0
slice1Display.DataAxesGrid.CullFrontface = 1
slice1Display.DataAxesGrid.ShowGrid = 0
slice1Display.DataAxesGrid.ShowEdges = 1
slice1Display.DataAxesGrid.ShowTicks = 1
slice1Display.DataAxesGrid.LabelUniqueEdgesOnly = 1
slice1Display.DataAxesGrid.AxesToLabel = 63
slice1Display.DataAxesGrid.XLabelFontFamily = 'Arial'
slice1Display.DataAxesGrid.XLabelFontFile = ''
slice1Display.DataAxesGrid.XLabelBold = 0
slice1Display.DataAxesGrid.XLabelItalic = 0
slice1Display.DataAxesGrid.XLabelFontSize = 12
slice1Display.DataAxesGrid.XLabelShadow = 0
slice1Display.DataAxesGrid.XLabelOpacity = 1.0
slice1Display.DataAxesGrid.YLabelFontFamily = 'Arial'
slice1Display.DataAxesGrid.YLabelFontFile = ''
slice1Display.DataAxesGrid.YLabelBold = 0
slice1Display.DataAxesGrid.YLabelItalic = 0
slice1Display.DataAxesGrid.YLabelFontSize = 12
slice1Display.DataAxesGrid.YLabelShadow = 0
slice1Display.DataAxesGrid.YLabelOpacity = 1.0
slice1Display.DataAxesGrid.ZLabelFontFamily = 'Arial'
slice1Display.DataAxesGrid.ZLabelFontFile = ''
slice1Display.DataAxesGrid.ZLabelBold = 0
slice1Display.DataAxesGrid.ZLabelItalic = 0
slice1Display.DataAxesGrid.ZLabelFontSize = 12
slice1Display.DataAxesGrid.ZLabelShadow = 0
slice1Display.DataAxesGrid.ZLabelOpacity = 1.0
slice1Display.DataAxesGrid.XAxisNotation = 'Mixed'
slice1Display.DataAxesGrid.XAxisPrecision = 2
slice1Display.DataAxesGrid.XAxisUseCustomLabels = 0
slice1Display.DataAxesGrid.XAxisLabels = []
slice1Display.DataAxesGrid.YAxisNotation = 'Mixed'
slice1Display.DataAxesGrid.YAxisPrecision = 2
slice1Display.DataAxesGrid.YAxisUseCustomLabels = 0
slice1Display.DataAxesGrid.YAxisLabels = []
slice1Display.DataAxesGrid.ZAxisNotation = 'Mixed'
slice1Display.DataAxesGrid.ZAxisPrecision = 2
slice1Display.DataAxesGrid.ZAxisUseCustomLabels = 0
slice1Display.DataAxesGrid.ZAxisLabels = []
slice1Display.DataAxesGrid.UseCustomBounds = 0
slice1Display.DataAxesGrid.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]

# init the 'PolarAxesRepresentation' selected for 'PolarAxes'
slice1Display.PolarAxes.Visibility = 0
slice1Display.PolarAxes.Translation = [0.0, 0.0, 0.0]
slice1Display.PolarAxes.Scale = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.Orientation = [0.0, 0.0, 0.0]
slice1Display.PolarAxes.EnableCustomBounds = [0, 0, 0]
slice1Display.PolarAxes.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
slice1Display.PolarAxes.EnableCustomRange = 0
slice1Display.PolarAxes.CustomRange = [0.0, 1.0]
slice1Display.PolarAxes.PolarAxisVisibility = 1
slice1Display.PolarAxes.RadialAxesVisibility = 1
slice1Display.PolarAxes.DrawRadialGridlines = 1
slice1Display.PolarAxes.PolarArcsVisibility = 1
slice1Display.PolarAxes.DrawPolarArcsGridlines = 1
slice1Display.PolarAxes.NumberOfRadialAxes = 0
slice1Display.PolarAxes.AutoSubdividePolarAxis = 1
slice1Display.PolarAxes.NumberOfPolarAxis = 0
slice1Display.PolarAxes.MinimumRadius = 0.0
slice1Display.PolarAxes.MinimumAngle = 0.0
slice1Display.PolarAxes.MaximumAngle = 90.0
slice1Display.PolarAxes.RadialAxesOriginToPolarAxis = 1
slice1Display.PolarAxes.Ratio = 1.0
slice1Display.PolarAxes.PolarAxisColor = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.PolarArcsColor = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.LastRadialAxisColor = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.SecondaryPolarArcsColor = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.SecondaryRadialAxesColor = [1.0, 1.0, 1.0]
slice1Display.PolarAxes.PolarAxisTitleVisibility = 1
slice1Display.PolarAxes.PolarAxisTitle = 'Radial Distance'
slice1Display.PolarAxes.PolarAxisTitleLocation = 'Bottom'
slice1Display.PolarAxes.PolarLabelVisibility = 1
slice1Display.PolarAxes.PolarLabelFormat = '%-#6.3g'
slice1Display.PolarAxes.PolarLabelExponentLocation = 'Labels'
slice1Display.PolarAxes.RadialLabelVisibility = 1
slice1Display.PolarAxes.RadialLabelFormat = '%-#3.1f'
slice1Display.PolarAxes.RadialLabelLocation = 'Bottom'
slice1Display.PolarAxes.RadialUnitsVisibility = 1
slice1Display.PolarAxes.ScreenSize = 10.0
slice1Display.PolarAxes.PolarAxisTitleOpacity = 1.0
slice1Display.PolarAxes.PolarAxisTitleFontFamily = 'Arial'
slice1Display.PolarAxes.PolarAxisTitleFontFile = ''
slice1Display.PolarAxes.PolarAxisTitleBold = 0
slice1Display.PolarAxes.PolarAxisTitleItalic = 0
slice1Display.PolarAxes.PolarAxisTitleShadow = 0
slice1Display.PolarAxes.PolarAxisTitleFontSize = 12
slice1Display.PolarAxes.PolarAxisLabelOpacity = 1.0
slice1Display.PolarAxes.PolarAxisLabelFontFamily = 'Arial'
slice1Display.PolarAxes.PolarAxisLabelFontFile = ''
slice1Display.PolarAxes.PolarAxisLabelBold = 0
slice1Display.PolarAxes.PolarAxisLabelItalic = 0
slice1Display.PolarAxes.PolarAxisLabelShadow = 0
slice1Display.PolarAxes.PolarAxisLabelFontSize = 12
slice1Display.PolarAxes.LastRadialAxisTextOpacity = 1.0
slice1Display.PolarAxes.LastRadialAxisTextFontFamily = 'Arial'
slice1Display.PolarAxes.LastRadialAxisTextFontFile = ''
slice1Display.PolarAxes.LastRadialAxisTextBold = 0
slice1Display.PolarAxes.LastRadialAxisTextItalic = 0
slice1Display.PolarAxes.LastRadialAxisTextShadow = 0
slice1Display.PolarAxes.LastRadialAxisTextFontSize = 12
slice1Display.PolarAxes.SecondaryRadialAxesTextOpacity = 1.0
slice1Display.PolarAxes.SecondaryRadialAxesTextFontFamily = 'Arial'
slice1Display.PolarAxes.SecondaryRadialAxesTextFontFile = ''
slice1Display.PolarAxes.SecondaryRadialAxesTextBold = 0
slice1Display.PolarAxes.SecondaryRadialAxesTextItalic = 0
slice1Display.PolarAxes.SecondaryRadialAxesTextShadow = 0
slice1Display.PolarAxes.SecondaryRadialAxesTextFontSize = 12
slice1Display.PolarAxes.EnableDistanceLOD = 1
slice1Display.PolarAxes.DistanceLODThreshold = 0.7
slice1Display.PolarAxes.EnableViewAngleLOD = 1
slice1Display.PolarAxes.ViewAngleLODThreshold = 0.7
slice1Display.PolarAxes.SmallestVisiblePolarAngle = 0.5
slice1Display.PolarAxes.PolarTicksVisibility = 1
slice1Display.PolarAxes.ArcTicksOriginToPolarAxis = 1
slice1Display.PolarAxes.TickLocation = 'Both'
slice1Display.PolarAxes.AxisTickVisibility = 1
slice1Display.PolarAxes.AxisMinorTickVisibility = 0
slice1Display.PolarAxes.ArcTickVisibility = 1
slice1Display.PolarAxes.ArcMinorTickVisibility = 0
slice1Display.PolarAxes.DeltaAngleMajor = 10.0
slice1Display.PolarAxes.DeltaAngleMinor = 5.0
slice1Display.PolarAxes.PolarAxisMajorTickSize = 0.0
slice1Display.PolarAxes.PolarAxisTickRatioSize = 0.3
slice1Display.PolarAxes.PolarAxisMajorTickThickness = 1.0
slice1Display.PolarAxes.PolarAxisTickRatioThickness = 0.5
slice1Display.PolarAxes.LastRadialAxisMajorTickSize = 0.0
slice1Display.PolarAxes.LastRadialAxisTickRatioSize = 0.3
slice1Display.PolarAxes.LastRadialAxisMajorTickThickness = 1.0
slice1Display.PolarAxes.LastRadialAxisTickRatioThickness = 0.5
slice1Display.PolarAxes.ArcMajorTickSize = 0.0
slice1Display.PolarAxes.ArcTickRatioSize = 0.3
slice1Display.PolarAxes.ArcMajorTickThickness = 1.0
slice1Display.PolarAxes.ArcTickRatioThickness = 0.5
slice1Display.PolarAxes.Use2DMode = 0
slice1Display.PolarAxes.UseLogAxis = 0

# hide data in view
Hide(resultsfoam, renderView1)

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# reset view to fit data
renderView1.ResetCamera(False)

# toggle 3D widget visibility (only when running from the GUI)
Hide3DWidgets(proxy=slice1.SliceType)

# reset view to fit data bounds
renderView1.ResetCamera(-0.0013647567247971892, 0.002347548259422183, -0.0069219558499753475, 0.012643578462302685, -0.018303455784916878, 0.03322876989841461, False)

# set scalar coloring
ColorBy(slice1Display, ('POINTS', 'U', 'Magnitude'))

# Hide the scalar bar for this color map if no visible data is colored by it.
HideScalarBarIfNotNeeded(pLUT, renderView1)

# rescale color and/or opacity maps used to include current data range
slice1Display.RescaleTransferFunctionToDataRange(True, False)

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)

# get color transfer function/color map for 'U'
uLUT = GetColorTransferFunction('U')

# get opacity transfer function/opacity map for 'U'
uPWF = GetOpacityTransferFunction('U')

# Rescale transfer function
uLUT.RescaleTransferFunction(0.0, 0.17863844187935898)

# Rescale transfer function
uPWF.RescaleTransferFunction(0.0, 0.17863844187935898)

# set scalar coloring
ColorBy(slice1Display, ('POINTS', 'U', 'Z'))

# rescale color and/or opacity maps used to exactly fit the current data range
slice1Display.RescaleTransferFunctionToDataRange(False, False)

# Update a scalar bar component title.
UpdateScalarBarsComponentTitle(uLUT, slice1Display)

# Rescale transfer function
uLUT.RescaleTransferFunction(0.0, 0.1716548651456833)

# Rescale transfer function
uPWF.RescaleTransferFunction(0.0, 0.1716548651456833)

# get layout
layout1 = GetLayout()

# layout/tab size in pixels
layout1.SetSize(3152, 1490)

# current camera placement for renderView1
renderView1.CameraPosition = [0.1072191909182476, 0.0028608113061636686, 0.007462657056748867]
renderView1.CameraFocalPoint = [0.0004913957673124969, 0.0028608113061636686, 0.007462657056748867]
renderView1.CameraViewUp = [0.0, 0.0, 1.0]
renderView1.CameraParallelScale = 0.027623186026862465

# save screenshot
SaveScreenshot('/home/y95228da/Desktop/Masc-compute-cases/MC-trial1/velocity.jpeg', renderView1, ImageResolution=[3152, 1490],
    FontScaling='Scale fonts proportionally',
    OverrideColorPalette='WhiteBackground',
    StereoMode='No change',
    TransparentBackground=0, 
    # JPEG options
    Quality=100,
    Progressive=1)

# set active source
SetActiveSource(resultsfoam)

# show data in view
resultsfoamDisplay = Show(resultsfoam, renderView1, 'UnstructuredGridRepresentation')

# show color bar/color legend
resultsfoamDisplay.SetScalarBarVisibility(renderView1, True)

# hide data in view
Hide(slice1, renderView1)

# Properties modified on resultsfoamDisplay
resultsfoamDisplay.Opacity = 0.9

# Properties modified on resultsfoamDisplay
resultsfoamDisplay.Opacity = 0.3

# turn off scalar coloring
ColorBy(resultsfoamDisplay, None)

# Hide the scalar bar for this color map if no visible data is colored by it.
HideScalarBarIfNotNeeded(pLUT, renderView1)

# create a new 'Stream Tracer'
streamTracer1 = StreamTracer(registrationName='StreamTracer1', Input=resultsfoam,
    SeedType='Line')
streamTracer1.Vectors = ['POINTS', 'U']
streamTracer1.InterpolatorType = 'Interpolator with Point Locator'
streamTracer1.SurfaceStreamlines = 0
streamTracer1.IntegrationDirection = 'BOTH'
streamTracer1.IntegratorType = 'Runge-Kutta 4-5'
streamTracer1.IntegrationStepUnit = 'Cell Length'
streamTracer1.InitialStepLength = 0.2
streamTracer1.MinimumStepLength = 0.01
streamTracer1.MaximumStepLength = 0.5
streamTracer1.MaximumSteps = 2000
streamTracer1.MaximumStreamlineLength = 0.05160355567932129
streamTracer1.TerminalSpeed = 1e-12
streamTracer1.MaximumError = 1e-06
streamTracer1.ComputeVorticity = 1

# init the 'Line' selected for 'SeedType'
streamTracer1.SeedType.Point1 = [-0.0063799237832427025, -0.007321463432163, -0.0183093324303627]
streamTracer1.SeedType.Point2 = [0.005840330850332975, 0.013354415073990822, 0.03329422324895859]
streamTracer1.SeedType.Resolution = 1000

# toggle 3D widget visibility (only when running from the GUI)
Show3DWidgets(proxy=streamTracer1.SeedType)

# Properties modified on streamTracer1
streamTracer1.SeedType = 'Point Cloud'

# show data in view
streamTracer1Display = Show(streamTracer1, renderView1, 'GeometryRepresentation')

# trace defaults for the display properties.
streamTracer1Display.Selection = None
streamTracer1Display.Representation = 'Surface'
streamTracer1Display.ColorArrayName = ['POINTS', 'p']
streamTracer1Display.LookupTable = pLUT
streamTracer1Display.MapScalars = 1
streamTracer1Display.MultiComponentsMapping = 0
streamTracer1Display.InterpolateScalarsBeforeMapping = 1
streamTracer1Display.Opacity = 1.0
streamTracer1Display.PointSize = 2.0
streamTracer1Display.LineWidth = 1.0
streamTracer1Display.RenderLinesAsTubes = 0
streamTracer1Display.RenderPointsAsSpheres = 0
streamTracer1Display.Interpolation = 'Gouraud'
streamTracer1Display.Specular = 0.0
streamTracer1Display.SpecularColor = [1.0, 1.0, 1.0]
streamTracer1Display.SpecularPower = 100.0
streamTracer1Display.Luminosity = 0.0
streamTracer1Display.Ambient = 0.0
streamTracer1Display.Diffuse = 1.0
streamTracer1Display.Roughness = 0.3
streamTracer1Display.Metallic = 0.0
streamTracer1Display.EdgeTint = [1.0, 1.0, 1.0]
streamTracer1Display.Anisotropy = 0.0
streamTracer1Display.AnisotropyRotation = 0.0
streamTracer1Display.BaseIOR = 1.5
streamTracer1Display.CoatStrength = 0.0
streamTracer1Display.CoatIOR = 2.0
streamTracer1Display.CoatRoughness = 0.0
streamTracer1Display.CoatColor = [1.0, 1.0, 1.0]
streamTracer1Display.SelectTCoordArray = 'None'
streamTracer1Display.SelectNormalArray = 'None'
streamTracer1Display.SelectTangentArray = 'None'
streamTracer1Display.Texture = None
streamTracer1Display.RepeatTextures = 1
streamTracer1Display.InterpolateTextures = 0
streamTracer1Display.SeamlessU = 0
streamTracer1Display.SeamlessV = 0
streamTracer1Display.UseMipmapTextures = 0
streamTracer1Display.ShowTexturesOnBackface = 1
streamTracer1Display.BaseColorTexture = None
streamTracer1Display.NormalTexture = None
streamTracer1Display.NormalScale = 1.0
streamTracer1Display.CoatNormalTexture = None
streamTracer1Display.CoatNormalScale = 1.0
streamTracer1Display.MaterialTexture = None
streamTracer1Display.OcclusionStrength = 1.0
streamTracer1Display.AnisotropyTexture = None
streamTracer1Display.EmissiveTexture = None
streamTracer1Display.EmissiveFactor = [1.0, 1.0, 1.0]
streamTracer1Display.FlipTextures = 0
streamTracer1Display.BackfaceRepresentation = 'Follow Frontface'
streamTracer1Display.BackfaceAmbientColor = [1.0, 1.0, 1.0]
streamTracer1Display.BackfaceOpacity = 1.0
streamTracer1Display.Position = [0.0, 0.0, 0.0]
streamTracer1Display.Scale = [1.0, 1.0, 1.0]
streamTracer1Display.Orientation = [0.0, 0.0, 0.0]
streamTracer1Display.Origin = [0.0, 0.0, 0.0]
streamTracer1Display.CoordinateShiftScaleMethod = 'Always Auto Shift Scale'
streamTracer1Display.Pickable = 1
streamTracer1Display.Triangulate = 0
streamTracer1Display.UseShaderReplacements = 0
streamTracer1Display.ShaderReplacements = ''
streamTracer1Display.NonlinearSubdivisionLevel = 1
streamTracer1Display.UseDataPartitions = 0
streamTracer1Display.OSPRayUseScaleArray = 'All Approximate'
streamTracer1Display.OSPRayScaleArray = 'p'
streamTracer1Display.OSPRayScaleFunction = 'PiecewiseFunction'
streamTracer1Display.OSPRayMaterial = 'None'
streamTracer1Display.BlockSelectors = ['/']
streamTracer1Display.BlockColors = []
streamTracer1Display.BlockOpacities = []
streamTracer1Display.Orient = 0
streamTracer1Display.OrientationMode = 'Direction'
streamTracer1Display.SelectOrientationVectors = 'Normals'
streamTracer1Display.Scaling = 0
streamTracer1Display.ScaleMode = 'No Data Scaling Off'
streamTracer1Display.ScaleFactor = 0.00511293187737465
streamTracer1Display.SelectScaleArray = 'p'
streamTracer1Display.GlyphType = 'Arrow'
streamTracer1Display.UseGlyphTable = 0
streamTracer1Display.GlyphTableIndexArray = 'p'
streamTracer1Display.UseCompositeGlyphTable = 0
streamTracer1Display.UseGlyphCullingAndLOD = 0
streamTracer1Display.LODValues = []
streamTracer1Display.ColorByLODIndex = 0
streamTracer1Display.GaussianRadius = 0.00025564659386873245
streamTracer1Display.ShaderPreset = 'Sphere'
streamTracer1Display.CustomTriangleScale = 4
streamTracer1Display.CustomShader = """ // This custom shader code define a gaussian blur
 // Please take a look into vtkSMPointGaussianRepresentation.cxx
 // for other custom shader examples
 //VTK::Color::Impl
   float dist2 = dot(offsetVCVSOutput.xy,offsetVCVSOutput.xy);
   float gaussian = exp(-0.5*dist2);
   opacity = opacity*gaussian;
"""
streamTracer1Display.Emissive = 0
streamTracer1Display.ScaleByArray = 0
streamTracer1Display.SetScaleArray = ['POINTS', 'p']
streamTracer1Display.ScaleArrayComponent = ''
streamTracer1Display.UseScaleFunction = 1
streamTracer1Display.ScaleTransferFunction = 'PiecewiseFunction'
streamTracer1Display.OpacityByArray = 0
streamTracer1Display.OpacityArray = ['POINTS', 'p']
streamTracer1Display.OpacityArrayComponent = ''
streamTracer1Display.OpacityTransferFunction = 'PiecewiseFunction'
streamTracer1Display.DataAxesGrid = 'GridAxesRepresentation'
streamTracer1Display.SelectionCellLabelBold = 0
streamTracer1Display.SelectionCellLabelColor = [0.0, 1.0, 0.0]
streamTracer1Display.SelectionCellLabelFontFamily = 'Arial'
streamTracer1Display.SelectionCellLabelFontFile = ''
streamTracer1Display.SelectionCellLabelFontSize = 18
streamTracer1Display.SelectionCellLabelItalic = 0
streamTracer1Display.SelectionCellLabelJustification = 'Left'
streamTracer1Display.SelectionCellLabelOpacity = 1.0
streamTracer1Display.SelectionCellLabelShadow = 0
streamTracer1Display.SelectionPointLabelBold = 0
streamTracer1Display.SelectionPointLabelColor = [1.0, 1.0, 0.0]
streamTracer1Display.SelectionPointLabelFontFamily = 'Arial'
streamTracer1Display.SelectionPointLabelFontFile = ''
streamTracer1Display.SelectionPointLabelFontSize = 18
streamTracer1Display.SelectionPointLabelItalic = 0
streamTracer1Display.SelectionPointLabelJustification = 'Left'
streamTracer1Display.SelectionPointLabelOpacity = 1.0
streamTracer1Display.SelectionPointLabelShadow = 0
streamTracer1Display.PolarAxes = 'PolarAxesRepresentation'

# init the 'PiecewiseFunction' selected for 'OSPRayScaleFunction'
streamTracer1Display.OSPRayScaleFunction.Points = [0.0, 0.0, 0.5, 0.0, 1.0, 1.0, 0.5, 0.0]
streamTracer1Display.OSPRayScaleFunction.UseLogScale = 0

# init the 'Arrow' selected for 'GlyphType'
streamTracer1Display.GlyphType.TipResolution = 6
streamTracer1Display.GlyphType.TipRadius = 0.1
streamTracer1Display.GlyphType.TipLength = 0.35
streamTracer1Display.GlyphType.ShaftResolution = 6
streamTracer1Display.GlyphType.ShaftRadius = 0.03
streamTracer1Display.GlyphType.Invert = 0

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
streamTracer1Display.ScaleTransferFunction.Points = [-0.00047082151286303997, 0.0, 0.5, 0.0, 0.033765777945518494, 1.0, 0.5, 0.0]
streamTracer1Display.ScaleTransferFunction.UseLogScale = 0

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
streamTracer1Display.OpacityTransferFunction.Points = [-0.00047082151286303997, 0.0, 0.5, 0.0, 0.033765777945518494, 1.0, 0.5, 0.0]
streamTracer1Display.OpacityTransferFunction.UseLogScale = 0

# init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
streamTracer1Display.DataAxesGrid.XTitle = 'X Axis'
streamTracer1Display.DataAxesGrid.YTitle = 'Y Axis'
streamTracer1Display.DataAxesGrid.ZTitle = 'Z Axis'
streamTracer1Display.DataAxesGrid.XTitleFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.XTitleFontFile = ''
streamTracer1Display.DataAxesGrid.XTitleBold = 0
streamTracer1Display.DataAxesGrid.XTitleItalic = 0
streamTracer1Display.DataAxesGrid.XTitleFontSize = 12
streamTracer1Display.DataAxesGrid.XTitleShadow = 0
streamTracer1Display.DataAxesGrid.XTitleOpacity = 1.0
streamTracer1Display.DataAxesGrid.YTitleFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.YTitleFontFile = ''
streamTracer1Display.DataAxesGrid.YTitleBold = 0
streamTracer1Display.DataAxesGrid.YTitleItalic = 0
streamTracer1Display.DataAxesGrid.YTitleFontSize = 12
streamTracer1Display.DataAxesGrid.YTitleShadow = 0
streamTracer1Display.DataAxesGrid.YTitleOpacity = 1.0
streamTracer1Display.DataAxesGrid.ZTitleFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.ZTitleFontFile = ''
streamTracer1Display.DataAxesGrid.ZTitleBold = 0
streamTracer1Display.DataAxesGrid.ZTitleItalic = 0
streamTracer1Display.DataAxesGrid.ZTitleFontSize = 12
streamTracer1Display.DataAxesGrid.ZTitleShadow = 0
streamTracer1Display.DataAxesGrid.ZTitleOpacity = 1.0
streamTracer1Display.DataAxesGrid.FacesToRender = 63
streamTracer1Display.DataAxesGrid.CullBackface = 0
streamTracer1Display.DataAxesGrid.CullFrontface = 1
streamTracer1Display.DataAxesGrid.ShowGrid = 0
streamTracer1Display.DataAxesGrid.ShowEdges = 1
streamTracer1Display.DataAxesGrid.ShowTicks = 1
streamTracer1Display.DataAxesGrid.LabelUniqueEdgesOnly = 1
streamTracer1Display.DataAxesGrid.AxesToLabel = 63
streamTracer1Display.DataAxesGrid.XLabelFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.XLabelFontFile = ''
streamTracer1Display.DataAxesGrid.XLabelBold = 0
streamTracer1Display.DataAxesGrid.XLabelItalic = 0
streamTracer1Display.DataAxesGrid.XLabelFontSize = 12
streamTracer1Display.DataAxesGrid.XLabelShadow = 0
streamTracer1Display.DataAxesGrid.XLabelOpacity = 1.0
streamTracer1Display.DataAxesGrid.YLabelFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.YLabelFontFile = ''
streamTracer1Display.DataAxesGrid.YLabelBold = 0
streamTracer1Display.DataAxesGrid.YLabelItalic = 0
streamTracer1Display.DataAxesGrid.YLabelFontSize = 12
streamTracer1Display.DataAxesGrid.YLabelShadow = 0
streamTracer1Display.DataAxesGrid.YLabelOpacity = 1.0
streamTracer1Display.DataAxesGrid.ZLabelFontFamily = 'Arial'
streamTracer1Display.DataAxesGrid.ZLabelFontFile = ''
streamTracer1Display.DataAxesGrid.ZLabelBold = 0
streamTracer1Display.DataAxesGrid.ZLabelItalic = 0
streamTracer1Display.DataAxesGrid.ZLabelFontSize = 12
streamTracer1Display.DataAxesGrid.ZLabelShadow = 0
streamTracer1Display.DataAxesGrid.ZLabelOpacity = 1.0
streamTracer1Display.DataAxesGrid.XAxisNotation = 'Mixed'
streamTracer1Display.DataAxesGrid.XAxisPrecision = 2
streamTracer1Display.DataAxesGrid.XAxisUseCustomLabels = 0
streamTracer1Display.DataAxesGrid.XAxisLabels = []
streamTracer1Display.DataAxesGrid.YAxisNotation = 'Mixed'
streamTracer1Display.DataAxesGrid.YAxisPrecision = 2
streamTracer1Display.DataAxesGrid.YAxisUseCustomLabels = 0
streamTracer1Display.DataAxesGrid.YAxisLabels = []
streamTracer1Display.DataAxesGrid.ZAxisNotation = 'Mixed'
streamTracer1Display.DataAxesGrid.ZAxisPrecision = 2
streamTracer1Display.DataAxesGrid.ZAxisUseCustomLabels = 0
streamTracer1Display.DataAxesGrid.ZAxisLabels = []
streamTracer1Display.DataAxesGrid.UseCustomBounds = 0
streamTracer1Display.DataAxesGrid.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]

# init the 'PolarAxesRepresentation' selected for 'PolarAxes'
streamTracer1Display.PolarAxes.Visibility = 0
streamTracer1Display.PolarAxes.Translation = [0.0, 0.0, 0.0]
streamTracer1Display.PolarAxes.Scale = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.Orientation = [0.0, 0.0, 0.0]
streamTracer1Display.PolarAxes.EnableCustomBounds = [0, 0, 0]
streamTracer1Display.PolarAxes.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
streamTracer1Display.PolarAxes.EnableCustomRange = 0
streamTracer1Display.PolarAxes.CustomRange = [0.0, 1.0]
streamTracer1Display.PolarAxes.PolarAxisVisibility = 1
streamTracer1Display.PolarAxes.RadialAxesVisibility = 1
streamTracer1Display.PolarAxes.DrawRadialGridlines = 1
streamTracer1Display.PolarAxes.PolarArcsVisibility = 1
streamTracer1Display.PolarAxes.DrawPolarArcsGridlines = 1
streamTracer1Display.PolarAxes.NumberOfRadialAxes = 0
streamTracer1Display.PolarAxes.AutoSubdividePolarAxis = 1
streamTracer1Display.PolarAxes.NumberOfPolarAxis = 0
streamTracer1Display.PolarAxes.MinimumRadius = 0.0
streamTracer1Display.PolarAxes.MinimumAngle = 0.0
streamTracer1Display.PolarAxes.MaximumAngle = 90.0
streamTracer1Display.PolarAxes.RadialAxesOriginToPolarAxis = 1
streamTracer1Display.PolarAxes.Ratio = 1.0
streamTracer1Display.PolarAxes.PolarAxisColor = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.PolarArcsColor = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.LastRadialAxisColor = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.SecondaryPolarArcsColor = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.SecondaryRadialAxesColor = [1.0, 1.0, 1.0]
streamTracer1Display.PolarAxes.PolarAxisTitleVisibility = 1
streamTracer1Display.PolarAxes.PolarAxisTitle = 'Radial Distance'
streamTracer1Display.PolarAxes.PolarAxisTitleLocation = 'Bottom'
streamTracer1Display.PolarAxes.PolarLabelVisibility = 1
streamTracer1Display.PolarAxes.PolarLabelFormat = '%-#6.3g'
streamTracer1Display.PolarAxes.PolarLabelExponentLocation = 'Labels'
streamTracer1Display.PolarAxes.RadialLabelVisibility = 1
streamTracer1Display.PolarAxes.RadialLabelFormat = '%-#3.1f'
streamTracer1Display.PolarAxes.RadialLabelLocation = 'Bottom'
streamTracer1Display.PolarAxes.RadialUnitsVisibility = 1
streamTracer1Display.PolarAxes.ScreenSize = 10.0
streamTracer1Display.PolarAxes.PolarAxisTitleOpacity = 1.0
streamTracer1Display.PolarAxes.PolarAxisTitleFontFamily = 'Arial'
streamTracer1Display.PolarAxes.PolarAxisTitleFontFile = ''
streamTracer1Display.PolarAxes.PolarAxisTitleBold = 0
streamTracer1Display.PolarAxes.PolarAxisTitleItalic = 0
streamTracer1Display.PolarAxes.PolarAxisTitleShadow = 0
streamTracer1Display.PolarAxes.PolarAxisTitleFontSize = 12
streamTracer1Display.PolarAxes.PolarAxisLabelOpacity = 1.0
streamTracer1Display.PolarAxes.PolarAxisLabelFontFamily = 'Arial'
streamTracer1Display.PolarAxes.PolarAxisLabelFontFile = ''
streamTracer1Display.PolarAxes.PolarAxisLabelBold = 0
streamTracer1Display.PolarAxes.PolarAxisLabelItalic = 0
streamTracer1Display.PolarAxes.PolarAxisLabelShadow = 0
streamTracer1Display.PolarAxes.PolarAxisLabelFontSize = 12
streamTracer1Display.PolarAxes.LastRadialAxisTextOpacity = 1.0
streamTracer1Display.PolarAxes.LastRadialAxisTextFontFamily = 'Arial'
streamTracer1Display.PolarAxes.LastRadialAxisTextFontFile = ''
streamTracer1Display.PolarAxes.LastRadialAxisTextBold = 0
streamTracer1Display.PolarAxes.LastRadialAxisTextItalic = 0
streamTracer1Display.PolarAxes.LastRadialAxisTextShadow = 0
streamTracer1Display.PolarAxes.LastRadialAxisTextFontSize = 12
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextOpacity = 1.0
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextFontFamily = 'Arial'
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextFontFile = ''
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextBold = 0
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextItalic = 0
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextShadow = 0
streamTracer1Display.PolarAxes.SecondaryRadialAxesTextFontSize = 12
streamTracer1Display.PolarAxes.EnableDistanceLOD = 1
streamTracer1Display.PolarAxes.DistanceLODThreshold = 0.7
streamTracer1Display.PolarAxes.EnableViewAngleLOD = 1
streamTracer1Display.PolarAxes.ViewAngleLODThreshold = 0.7
streamTracer1Display.PolarAxes.SmallestVisiblePolarAngle = 0.5
streamTracer1Display.PolarAxes.PolarTicksVisibility = 1
streamTracer1Display.PolarAxes.ArcTicksOriginToPolarAxis = 1
streamTracer1Display.PolarAxes.TickLocation = 'Both'
streamTracer1Display.PolarAxes.AxisTickVisibility = 1
streamTracer1Display.PolarAxes.AxisMinorTickVisibility = 0
streamTracer1Display.PolarAxes.ArcTickVisibility = 1
streamTracer1Display.PolarAxes.ArcMinorTickVisibility = 0
streamTracer1Display.PolarAxes.DeltaAngleMajor = 10.0
streamTracer1Display.PolarAxes.DeltaAngleMinor = 5.0
streamTracer1Display.PolarAxes.PolarAxisMajorTickSize = 0.0
streamTracer1Display.PolarAxes.PolarAxisTickRatioSize = 0.3
streamTracer1Display.PolarAxes.PolarAxisMajorTickThickness = 1.0
streamTracer1Display.PolarAxes.PolarAxisTickRatioThickness = 0.5
streamTracer1Display.PolarAxes.LastRadialAxisMajorTickSize = 0.0
streamTracer1Display.PolarAxes.LastRadialAxisTickRatioSize = 0.3
streamTracer1Display.PolarAxes.LastRadialAxisMajorTickThickness = 1.0
streamTracer1Display.PolarAxes.LastRadialAxisTickRatioThickness = 0.5
streamTracer1Display.PolarAxes.ArcMajorTickSize = 0.0
streamTracer1Display.PolarAxes.ArcTickRatioSize = 0.3
streamTracer1Display.PolarAxes.ArcMajorTickThickness = 1.0
streamTracer1Display.PolarAxes.ArcTickRatioThickness = 0.5
streamTracer1Display.PolarAxes.Use2DMode = 0
streamTracer1Display.PolarAxes.UseLogAxis = 0

# show color bar/color legend
streamTracer1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# Properties modified on streamTracer1Display
streamTracer1Display.LineWidth = 3.0

# update the view to ensure updated data information
renderView1.Update()

# update the view to ensure updated data information
renderView1.Update()

# update the view to ensure updated data information
renderView1.Update()

# update the view to ensure updated data information
renderView1.Update()

# update the view to ensure updated data information
renderView1.Update()

# Properties modified on streamTracer1Display
streamTracer1Display.LineWidth = 2.0

# set scalar coloring
ColorBy(streamTracer1Display, ('POINTS', 'Vorticity', 'Magnitude'))

# Hide the scalar bar for this color map if no visible data is colored by it.
HideScalarBarIfNotNeeded(pLUT, renderView1)

# rescale color and/or opacity maps used to include current data range
streamTracer1Display.RescaleTransferFunctionToDataRange(True, False)

# show color bar/color legend
streamTracer1Display.SetScalarBarVisibility(renderView1, True)

# get color transfer function/color map for 'Vorticity'
vorticityLUT = GetColorTransferFunction('Vorticity')

# get opacity transfer function/opacity map for 'Vorticity'
vorticityPWF = GetOpacityTransferFunction('Vorticity')

# Rescale transfer function
vorticityLUT.RescaleTransferFunction(0.0, 300.0)

# Rescale transfer function
vorticityPWF.RescaleTransferFunction(0.0, 300.0)

# Rescale transfer function
vorticityLUT.RescaleTransferFunction(0.0, 200.0)

# Rescale transfer function
vorticityPWF.RescaleTransferFunction(0.0, 200.0)

# toggle 3D widget visibility (only when running from the GUI)
Hide3DWidgets(proxy=streamTracer1.SeedType)

# layout/tab size in pixels
layout1.SetSize(3152, 1490)

# current camera placement for renderView1
renderView1.CameraPosition = [0.10299369680286471, -0.0039123283935798454, 0.03641477474793783]
renderView1.CameraFocalPoint = [0.0004913957673125026, 0.002860811306163669, 0.007462657056748862]
renderView1.CameraViewUp = [-0.27138782200093353, 0.006931510010869261, 0.9624451175202454]
renderView1.CameraParallelScale = 0.027623186026862465

# save screenshot
SaveScreenshot('/home/y95228da/Desktop/Masc-compute-cases/MC-trial1/streamlines.jpeg', renderView1, ImageResolution=[3152, 1490],
    FontScaling='Scale fonts proportionally',
    OverrideColorPalette='WhiteBackground',
    StereoMode='No change',
    TransparentBackground=0, 
    # JPEG options
    Quality=95,
    Progressive=1)

# hide data in view
Hide(streamTracer1, renderView1)

# set active source
SetActiveSource(slice1)

# show data in view
slice1Display = Show(slice1, renderView1, 'GeometryRepresentation')

# show color bar/color legend
slice1Display.SetScalarBarVisibility(renderView1, True)

# hide data in view
Hide(resultsfoam, renderView1)

# turn off scalar coloring
ColorBy(slice1Display, None)

# Hide the scalar bar for this color map if no visible data is colored by it.
HideScalarBarIfNotNeeded(uLUT, renderView1)

# change representation type
slice1Display.SetRepresentationType('Surface With Edges')

# layout/tab size in pixels
layout1.SetSize(3152, 1490)

# current camera placement for renderView1
renderView1.CameraPosition = [0.10299369680286471, -0.0039123283935798454, 0.03641477474793783]
renderView1.CameraFocalPoint = [0.0004913957673125026, 0.002860811306163669, 0.007462657056748862]
renderView1.CameraViewUp = [-0.27138782200093353, 0.006931510010869261, 0.9624451175202454]
renderView1.CameraParallelScale = 0.027623186026862465

# save screenshot
SaveScreenshot('/home/y95228da/Desktop/Masc-compute-cases/MC-trial1/mesh.jpeg', renderView1, ImageResolution=[3152, 1490],
    FontScaling='Scale fonts proportionally',
    OverrideColorPalette='WhiteBackground',
    StereoMode='No change',
    TransparentBackground=0, 
    # JPEG options
    Quality=95,
    Progressive=1)

#================================================================
# addendum: following script captures some of the application
# state to faithfully reproduce the visualization during playback
#================================================================

#--------------------------------
# saving layout sizes for layouts

# layout/tab size in pixels
layout1.SetSize(3152, 1490)

#-----------------------------------
# saving camera placements for views

# current camera placement for renderView1
renderView1.CameraPosition = [0.10299369680286471, -0.0039123283935798454, 0.03641477474793783]
renderView1.CameraFocalPoint = [0.0004913957673125026, 0.002860811306163669, 0.007462657056748862]
renderView1.CameraViewUp = [-0.27138782200093353, 0.006931510010869261, 0.9624451175202454]
renderView1.CameraParallelScale = 0.027623186026862465

#--------------------------------------------
# uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).
