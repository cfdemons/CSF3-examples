#!/bin/bash

#Run this with sbatch abq_run.sh
#Check current position with sacct

#Job name:
#SBATCH --job-name=AbaqusJob 

#Request Resources:
# 1 node = 1 computer. keep 1 for mp_mode=threads
#SBATCH --nodes=1
#
#Number of tasks to run on each node: - number of processors to use in 1 computer (node)
#SBATCH --ntasks-per-node=1
#
#Number of CPUs (threads) to use: - number of threads per core. Max =28. CHANGE THIS ONE!!
#SBATCH --cpus-per-task=2
#
#Run time (Days-Hours:Mins:Secs)
#SBATCH --time=0-05:00:00
#
#Memory per node. Max =100000M (100G)
#SBATCH --mem=50000M


cd $SLURM_SUBMIT_DIR

#This is used to stop the error: "<IBM Platform MPI>: : warning, dlopen of libhwloc.so failed"
unset SLURM_GTIDS


#=================================
#Load Modules:
#Abaqus:
module load apps/abaqus/2018
#Intel Compiler (ifort):
module load ifort/2017.1.132-GCC-5.4.0-2.26

#Add MPI module?

#=================================

#Run job script/commands

#openMP thread export
echo 'Number of Cores:'
echo $SLURM_CPUS_PER_TASK

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
#

#mp_mode=threads
abaqus job=AbaqusJob input=Job-1.inp user=BRISTOL.for cpus=$SLURM_CPUS_PER_TASK scratch=$TMPDIR memory=$SLURM_MEM_PER_NODE interactive


#=================================