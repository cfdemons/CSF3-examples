import os

# Get the current folder path
current_folder_path = os.getcwd()

# Define the file name
file_name = 'BRISTOL.for'  # Replace with the actual file name

# Create the full file path
file_path = os.path.join(current_folder_path, file_name)

# Read the file content
with open(file_path, 'r') as file:
    lines = file.readlines()

# Iterate through the lines and replace the desired line
for i, line in enumerate(lines):
    if 'foldername=' in line:
        lines[i] = f'          foldername= "{current_folder_path}"\n'

# Write the modified content back to the file
with open(file_path, 'w') as file:
    file.writelines(lines)
