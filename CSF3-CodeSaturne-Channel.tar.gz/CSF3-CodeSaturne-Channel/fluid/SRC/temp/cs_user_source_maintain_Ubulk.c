#include "cs_defs.h"

/*----------------------------------------------------------------------------
 * Standard C library headers
 *----------------------------------------------------------------------------*/

#include <assert.h>
#include <math.h>

/*----------------------------------------------------------------------------
 * PLE library headers
 *----------------------------------------------------------------------------*/

#include <ple_coupling.h>

/*----------------------------------------------------------------------------
 * Local headers
 *----------------------------------------------------------------------------*/

#include "cs_headers.h"

/*----------------------------------------------------------------------------*/

BEGIN_C_DECLS

void
cs_user_source_terms(cs_domain_t  *domain,
                     int           f_id,
                     cs_real_t    *st_exp,
                     cs_real_t    *st_imp)
{
  /* field structure */
  const cs_field_t  *f = cs_field_by_id(f_id);

  /* mesh quantities */
  const cs_lnum_t  n_cells = domain->mesh->n_cells;
  const cs_real_t  *cell_f_vol = domain->mesh_quantities->cell_vol;

  /* density */
  const cs_real_t  *cpro_rom = CS_F_(rho)->val;

  /* velocity */
  const cs_real_3_t  *cvar_vel = (const cs_real_3_t *)(CS_F_(vel)->val);

  /* bulk mean velocity (x component) */
  cs_real_t ubulk = 0;
  for (cs_lnum_t i = 0; i < n_cells; i++) {
    ubulk += cvar_vel[i][0] * cell_f_vol[i];
  }

  cs_parall_sum(1, CS_DOUBLE, &ubulk);  /* sum across processes if needed */

  ubulk /= cs_glob_mesh_quantities->tot_vol;

  /* Target bulk velocity */
  cs_real_t ubulk_target = 1.0;
  
  if (f == CS_F_(vel)) { /* velocity */

  /* Calculate the correction factor */
  cs_real_t correction_factor = ubulk_target - ubulk;

  /* Apply the source term to the x-component of velocity */
  
  cs_real_3_t  *_st_exp = (cs_real_3_t *)st_exp;
  
  for (cs_lnum_t i = 0; i < n_cells; i++) {
    _st_exp[i][0] = cell_f_vol[i] * correction_factor;
    _st_imp[i][0] = 0.0;  /* No implicit part */
  }
}

END_C_DECLS
