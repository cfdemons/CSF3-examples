import numpy as np
import re

def getNumberFromString(str):
    # Remove all characters except '.' and '-' and 'e' in a string and convert it to a float number
    filtered_string = ''.join(c if c.isdigit() or c in '.-e' else '' for c in str)
    
    return float(filtered_string) if filtered_string else None
    
def findKeyLine(rawtext,keytext):
    # Find the line number including keytext (first occurrence) from rawtext
    pattern = re.compile(r'\b' + re.escape(keytext) + r'\b')
    
    nline = len(rawtext)
    for i in range(nline):
        line=rawtext[i]
        if pattern.search(line):
            keyline=i
            break
    return keyline  
