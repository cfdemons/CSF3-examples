import numpy as np
from functionsOther import *
import matplotlib.pyplot as plt

def loadFieldAvgXZt_CodeSaturne(fdir,varname,time1,time2,nx,ny,nz,gi,nc):

    headerlines = 4
    
    # Output frequency
    outFreq = getOutputFreq(fdir)
    
    field1D = np.zeros(nc)
    field3D = np.zeros((nx,ny,nz))
    meanProf1= np.zeros(ny)
    meanProf2= np.zeros(ny)
    meanProf= np.zeros(ny)
    
    # === Load field at time 1 and average in x and z directions
       
    fname = 'results_fluid_domain.'+varname+'.'+str(int(time1/outFreq)).zfill(5)
    
    # Find out the line that is not a number
    with open(fdir+fname, 'r') as fid:
        for i in range(headerlines):
            fid.readline()
        for i in range(nc):
            field1D[i] = float(fid.readline())
                
    for i in range(nc):
        field3D[gi[i, 0], gi[i, 1], gi[i, 2]] = field1D[i]

    meanProf1 = np.mean(field3D[1:-1,:,:], axis=(0, 2))
    
    # === Load field at time 2 and average in x and z directions   
    
    fname = 'results_fluid_domain.'+varname+'.'+str(int(time2/outFreq)).zfill(5)

    with open(fdir+fname, 'r') as fid:
        for i in range(headerlines):
            fid.readline()
        for i in range(nc):
            field1D[i] = float(fid.readline())
    
    for i in range(nc):
        field3D[gi[i, 0], gi[i, 1], gi[i, 2]] = field1D[i]

    meanProf2 = np.mean(field3D[1:-1,:,:], axis=(0, 2)) 
    
    # === Time average between time 1 and 2
    
    meanProf = (meanProf2*time2-meanProf1*time1)/(time2-time1)

    return meanProf
    
def getOutputFreq(fdir):
    
    fname = 'RESULTS_FLUID_DOMAIN.case'
    
    with open(fdir+fname, 'r') as fid:
        rawtext = fid.readlines()
        
    skiplines = findKeyLine(rawtext,'time values')
    
    with open(fdir+fname, 'r') as fid:
        for i in range(skiplines+1):
            fid.readline()
        t1 = float(fid.readline())
        t2 = float(fid.readline())
        
    outFreq = t2 - t1
    
    return outFreq

def sortMesh(xyz, err):
    # Define the tolerance for sorting
    nc = xyz.shape[0]
    
    # Initialize variables
    nn = np.zeros(3, dtype=int)
    nn[:]=-1

    xline = []

    # Sort mesh grid
    for i in range(nc):
        if i == 0:
            nn += 1
            xline.append(xyz[0, :])
        else:
            for j in range(3):
                iflag = True
                for n in range(nn[j]+1):
                    if abs(xline[n][j] - xyz[i,j]) < err:
                        iflag = False
                        break
                if iflag:
                    nn[j] += 1
                    xline.append(np.zeros(3))
                    xline[nn[j]][j]=xyz[i,j]

    xline = np.array(xline)
    nn=nn+1

    # Extract x, y and z mesh grids
    xg = xline[:nn[0], 0]
    yg = xline[:nn[1], 1]
    zg = xline[:nn[2], 2]
    
    xg = np.sort(xg)
    yg = np.sort(yg)
    zg = np.sort(zg)

    nx = len(xg)
    ny = len(yg)
    nz = len(zg)
    
    nc_real = int(nx*ny*nz)

    # Output mesh information
    print("   ")
    print("*** This program sorts the mesh from disorganised to organised form ***")
    print("   ")
    print("     - Finish sorting cell-centre mesh:")
    print("     - Total number of cells: "+str(nc_real))
    print("     - Number of cells in x direction: "+str(nx))
    print("     - Number of cells in y direction: "+str(ny))
    print("     - Number of cells in z direction: "+str(nz))
    print("   ")

    # Corresponding mesh IDs for all cells
    gi = np.zeros((nc, 3), dtype=int)
    gi = gi - 1

    for i in range(nc):
        gi[i, 0] = np.argmin(np.abs(xyz[i, 0] - xg))
        gi[i, 1] = np.argmin(np.abs(xyz[i, 1] - yg))
        gi[i, 2] = np.argmin(np.abs(xyz[i, 2] - zg))

    return xg, yg, zg, gi, nx, ny, nz, nc
    
def avgSymm(U):
    ny = U.shape[0]
    
    Usym = U

    for i in range(ny):
        Usym[i] = ( U[i] + U[ny-1-i] )/2.
    
    return Usym

def getTol(xyz,idir):
    zeroNum = 1.e-12

    g1d = abs(xyz[:,idir])
    ng = len(g1d) # Number of grids
    
    ymax = max(g1d)
    
    for i in range(ng):
        if g1d[i]<zeroNum:
          g1d[i] = ymax
    
    tol = min(g1d)*2
    
    return tol
