#!/usr/bin/env python
import sys
import salome
import salome_notebook
import GEOM
from salome.geom import geomBuilder
import math
import SALOMEDS

salome.salome_init()
notebook = salome_notebook.NoteBook()
sys.path.insert(0, r'.')

# -----------------------------------------------------------------
# This script generates the mesh of a channel
#
#    x: flow direction
#    y: wall normal direction
#    z: transverse direction
# 
# Parameters that needs to be specified:
#
#    1. ch (full-channel height)
#    2. basex, basey, basez (base-point coordinates of the channel)
#    3. dx, dy, dz (channel-size in x, y, z directions)
#    4. nx, ny, nz (cell-numbers in x, y, z directions)
# -----------------------------------------------------------------

ch = 2.                 # Full-channel height (distance between top & bottom plates)

# === Geometry parameters
pi = 3.141592654
#Base point
basex = 0.
basey = 0.
basez = 0.
#Channel size
dx=4
dy=ch
dz=2

# === Mesh parameters
nx=50
ny=50
nz=70

bf=40     # Bias factor, the bigger the finner near-wall mesh
wl=.05    # wall layer, from wall to wl*ch, a finer mesh is applied

# === Build Geometry
print(f'  ')
print(f'  Build channel geometry ...')

geompy = geomBuilder.New()

O = geompy.MakeVertex(0, 0, 0)
OX = geompy.MakeVectorDXDYDZ(1, 0, 0)
OY = geompy.MakeVectorDXDYDZ(0, 1, 0)
OZ = geompy.MakeVectorDXDYDZ(0, 0, 1)

#Create base point
Bot1_ch = geompy.MakeVertex(basex,    basey,    basez)
Bot2_ch = geompy.MakeVertex(basex+dx, basey,    basez)
Bot3_ch = geompy.MakeVertex(basex+dx, basey+dy, basez)
Bot4_ch = geompy.MakeVertex(basex,    basey+dy, basez)

#Build lines by connecting points
Line1 = geompy.MakeLineTwoPnt(Bot1_ch, Bot2_ch)
Line2 = geompy.MakeLineTwoPnt(Bot2_ch, Bot3_ch)
Line3 = geompy.MakeLineTwoPnt(Bot3_ch, Bot4_ch)
Line4 = geompy.MakeLineTwoPnt(Bot4_ch, Bot1_ch)

#Build the bottom surface by connecting lines
BotFace = geompy.MakeFaceWires([Line1, Line2, Line3, Line4], 1)

#Build the block channel by extruding the bottom surface
Extru1 = geompy.MakePrismVecH(BotFace, OZ, dz)

#Group lines, faces and volumes (for mesh)
lines_wallnormal = geompy.CreateGroup(Extru1, geompy.ShapeType["EDGE"])
geompy.UnionIDs(lines_wallnormal, [19, 29, 30, 18])
lines_transverse = geompy.CreateGroup(Extru1, geompy.ShapeType["EDGE"])
geompy.UnionIDs(lines_transverse, [22, 8, 15, 5])
lines_streamwise = geompy.CreateGroup(Extru1, geompy.ShapeType["EDGE"])
geompy.UnionIDs(lines_streamwise, [25, 26, 12, 11])
top = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(top, [20])
bot = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(bot, [3])
inlet = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(inlet, [27])
outlet = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(outlet, [13])
front = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(front, [33])
back = geompy.CreateGroup(Extru1, geompy.ShapeType["FACE"])
geompy.UnionIDs(back, [31])
fluid = geompy.CreateGroup(Extru1, geompy.ShapeType["SOLID"])
geompy.UnionIDs(fluid, [1])

#Show items in the interface
geompy.addToStudy( O, 'O' )
geompy.addToStudy( OX, 'OX' )
geompy.addToStudy( OY, 'OY' )
geompy.addToStudy( OZ, 'OZ' )
geompy.addToStudy( Extru1, 'channel_geo' )

geompy.addToStudyInFather( Extru1, lines_wallnormal, 'lines_wallnormal' )
geompy.addToStudyInFather( Extru1, lines_transverse, 'lines_transverse' )
geompy.addToStudyInFather( Extru1, lines_streamwise, 'lines_streamwise' )
geompy.addToStudyInFather( Extru1, top, 'top' )
geompy.addToStudyInFather( Extru1, bot, 'bot' )
geompy.addToStudyInFather( Extru1, inlet, 'inlet' )
geompy.addToStudyInFather( Extru1, outlet, 'outlet' )
geompy.addToStudyInFather( Extru1, front, 'front' )
geompy.addToStudyInFather( Extru1, back, 'back' )
geompy.addToStudyInFather( Extru1, fluid, 'fluid' )

print(f'  Success! ...')

# === Build Mesh
import  SMESH, SALOMEDS
from salome.smesh import smeshBuilder

print(f'  Build channel mesh ...')

smesh = smeshBuilder.New()

channel_mesh = smesh.Mesh(Extru1,'channel_mesh')
Regular_1D = channel_mesh.Segment()
Quadrangle_2D = channel_mesh.Quadrangle(algo=smeshBuilder.QUADRANGLE)
Hexa_3D = channel_mesh.Hexahedron(algo=smeshBuilder.Hexa)

smesh.SetName(Regular_1D.GetAlgorithm(), 'Regular_1D')
smesh.SetName(Quadrangle_2D.GetAlgorithm(), 'Quadrangle_2D')
smesh.SetName(Hexa_3D.GetAlgorithm(), 'Hexa_3D')
smesh.SetName(channel_mesh.GetMesh(), 'channel_mesh')

#Sub-meshes

#Streamwise
Regular_1D_1 = channel_mesh.Segment(geom=lines_streamwise)
gridnumber_streamwise = Regular_1D_1.NumberOfSegments(nx)
submesh_streamwise = Regular_1D_1.GetSubMesh()
smesh.SetName(gridnumber_streamwise, 'gridnumber_streamwise')
smesh.SetName(submesh_streamwise, 'submesh_streamwise')

#Tranverse
Regular_1D_2 = channel_mesh.Segment(geom=lines_transverse)
gridnumber_transverse = Regular_1D_2.NumberOfSegments(nz)
submesh_transverse = Regular_1D_2.GetSubMesh()
smesh.SetName(gridnumber_transverse, 'gridnumber_transverse')
smesh.SetName(submesh_transverse, 'submesh_transverse')

#Wall-normal
Regular_1D_3 = channel_mesh.Segment(geom=lines_wallnormal)
gridnumber_wallnormal = Regular_1D_3.NumberOfSegments(ny)
gridnumber_wallnormal.SetConversionMode( 1 )
gridnumber_wallnormal.SetTableFunction( [ 0., 1, wl, 5/bf, .5, 1/bf, 1-wl, 5/bf, 1., 1 ] )

#gridnumber_wallnormal.SetNumberOfSegments( ny )
#gridnumber_wallnormal.SetConversionMode( 1 )
#gridnumber_wallnormal.SetReversedEdges( [] )
#gridnumber_wallnormal.SetExpressionFunction( 'cosh('+str(bf)+'*(t-0.5))/cosh(0.5)' )

submesh_wallnormal = Regular_1D_3.GetSubMesh()
smesh.SetName(gridnumber_wallnormal, 'gridnumber_wallnormal')
smesh.SetName(submesh_wallnormal, 'submesh_wallnormal')

#Face projection (for periodic/cyclic faces)
Projection_1D2D = channel_mesh.Projection1D2D(geom=front)
cyclic_projection_front = Projection_1D2D.GetSubMesh()
Source_Face_1 = Projection_1D2D.SourceFace(back,None,None,None,None,None)

#Add surfaces and volumes from geometry
meshface_front = channel_mesh.GroupOnGeom(front,'front',SMESH.FACE)
meshface_back = channel_mesh.GroupOnGeom(back,'back',SMESH.FACE)
meshface_inlet = channel_mesh.GroupOnGeom(inlet,'inlet',SMESH.FACE)
meshface_outlet = channel_mesh.GroupOnGeom(outlet,'outlet',SMESH.FACE)
meshface_top = channel_mesh.GroupOnGeom(top,'top',SMESH.FACE)
meshface_bot = channel_mesh.GroupOnGeom(bot,'bot',SMESH.FACE)
meshvolume_fluid = channel_mesh.GroupOnGeom(fluid,'fluid',SMESH.VOLUME)

smesh.SetName(meshface_front, 'front')
smesh.SetName(meshface_back, 'back')
smesh.SetName(meshface_inlet, 'inlet')
smesh.SetName(meshface_outlet, 'outlet')
smesh.SetName(meshface_top, 'top')
smesh.SetName(meshface_bot, 'bot')
smesh.SetName(meshvolume_fluid, 'fluid')

#Compute mesh
isDone = channel_mesh.SetMeshOrder( [ [ cyclic_projection_front, submesh_streamwise, submesh_wallnormal, submesh_transverse   ] ])
isDone = channel_mesh.Compute()

print(f'  Success! ...')

#Export mesh
print(f'  Exporting mesh to .unv ...')
channel_mesh.ExportUNV( r'./channel_mesh.unv')
print(f'  Success! ...')

if salome.sg.hasDesktop():
  salome.sg.updateObjBrowser()


